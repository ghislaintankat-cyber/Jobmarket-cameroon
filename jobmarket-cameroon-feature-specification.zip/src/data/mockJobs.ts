export interface Job {
  id: string;
  title: string;
  category: string;
  categoryIcon: string;
  price: number;
  currency: string;
  phone: string;
  landmark: string;
  city: string;
  desc: string;
  images: string[];
  lat: number;
  lng: number;
  timestamp: number;
  status: 'open' | 'in_progress' | 'completed' | 'cancelled';
  verified: boolean;
  
  // LinkedIn / Upwork elements
  provider: {
    uid: string;
    name: string;
    avatar: string;
    role: string;
    skills: string[];
    trustScore: number; // 0 to 100
    completedJobs: number;
    responseRate: number; // %
    badges: ('verified' | 'top_rated' | 'id_checked' | 'fast_responder')[];
    ratingAvg: number;
    reviewsCount: number;
  };
  
  // Uber elements
  distanceKm: number;
  etaMinutes: number;
  
  // Moderation / Security
  fraudScore: number; // 0 to 100 calculated by simulated AI
  reported: boolean;
  reportReason?: string;
}

export const INITIAL_JOBS: Job[] = [
  {
    id: "job-1",
    title: "Installation Électrique Triphasée Résidentielle",
    category: "⚡ Électricité",
    categoryIcon: "⚡",
    price: 125000,
    currency: "XAF",
    phone: "+237677123456",
    landmark: "Bastos, Face Ambassade",
    city: "Yaoundé",
    desc: "Recherche d'un électricien certifié pour la réfection complète d'un tableau triphasé et l'installation d'inverseurs automatiques pour un groupe électrogène de 15KVA.",
    images: [
      "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1581092921461-eab62e97a780?auto=format&fit=crop&w=600&q=80"
    ],
    lat: 3.878,
    lng: 11.512,
    timestamp: Date.now() - 3600000,
    status: 'open',
    verified: true,
    provider: {
      uid: "usr-99",
      name: "Ing. Marc FOMBA",
      avatar: "👨‍🔧",
      role: "Électricien Industriel Sénior",
      skills: ["Câblage armoire", "Groupes Électrogènes", "Normes NFC 15-100"],
      trustScore: 98,
      completedJobs: 47,
      responseRate: 99,
      badges: ["verified", "top_rated", "id_checked"],
      ratingAvg: 4.9,
      reviewsCount: 32
    },
    distanceKm: 1.4,
    etaMinutes: 6,
    fraudScore: 3,
    reported: false
  },
  {
    id: "job-2",
    title: "Chantier BTP - Coffrage et Maçonnerie de Dalle",
    category: "🔧 BTP",
    categoryIcon: "🔧",
    price: 450000,
    currency: "XAF",
    phone: "+237699887766",
    landmark: "Akwa, Rue de la Joie",
    city: "Douala",
    desc: "Besoin urgent d'un chef coffreur et d'une équipe de 4 maçons qualifiés pour couler une dalle de 180m². Matériel fourni (étais, planches, bétonnière mécanique dispo). Rémunération par étape validée.",
    images: [
      "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=600&q=80"
    ],
    lat: 4.048,
    lng: 9.704,
    timestamp: Date.now() - 7200000,
    status: 'open',
    verified: true,
    provider: {
      uid: "usr-88",
      name: "Amadou TCHANKOU",
      avatar: "👷‍♂️",
      role: "Entrepreneur BTP / Gros Œuvre",
      skills: ["Génie Civil", "Coffrage Armé", "Lecture de plan"],
      trustScore: 95,
      completedJobs: 112,
      responseRate: 94,
      badges: ["verified", "id_checked", "fast_responder"],
      ratingAvg: 4.7,
      reviewsCount: 89
    },
    distanceKm: 3.8,
    etaMinutes: 12,
    fraudScore: 1,
    reported: false
  },
  {
    id: "job-3",
    title: "Dépannage Plomberie & Fuite Encastrée",
    category: "💧 Plomberie",
    categoryIcon: "💧",
    price: 35000,
    currency: "XAF",
    phone: "+237655443322",
    landmark: "Bonapriso, Près de Super U",
    city: "Douala",
    desc: "Fuite d'eau suspecte détectée sous la chape du rez-de-chaussée. Trace d'humidité sur 3 mètres. Intervention avec détecteur thermique ou acoustique souhaitée.",
    images: [
      "https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?auto=format&fit=crop&w=600&q=80"
    ],
    lat: 4.025,
    lng: 9.692,
    timestamp: Date.now() - 15000000,
    status: 'in_progress',
    verified: true,
    provider: {
      uid: "usr-77",
      name: "Samuel EBOUÉ",
      avatar: "👨‍🔧",
      role: "Artisan Plombier Certifié",
      skills: ["Tuyauterie PPR", "Détection fuites", "Rénovation Douche"],
      trustScore: 92,
      completedJobs: 24,
      responseRate: 88,
      badges: ["verified", "id_checked"],
      ratingAvg: 4.6,
      reviewsCount: 15
    },
    distanceKm: 0.8,
    etaMinutes: 4,
    fraudScore: 5,
    reported: false
  },
  {
    id: "job-4",
    title: "Nettoyage Fin de Chantier & Ménage Grand Standing",
    category: "🧹 Ménage",
    categoryIcon: "🧹",
    price: 80000,
    currency: "XAF",
    phone: "+237688554433",
    landmark: "Kribi, Zone Résidentielle Chinoise",
    city: "Kribi",
    desc: "Nettoyage complet d'une villa de 5 pièces après peinture : retrait des traces de ciment, lustrage des carreaux et lavage haute pression de la terrasse.",
    images: [
      "https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=600&q=80"
    ],
    lat: 2.951,
    lng: 9.908,
    timestamp: Date.now() - 22000000,
    status: 'open',
    verified: false,
    provider: {
      uid: "usr-66",
      name: "Clarisse MBANGO",
      avatar: "👩‍💼",
      role: "Superviseuse Propreté & Services",
      skills: ["Lustrage marbre", "Shampoing Moquette", "Désinfection"],
      trustScore: 84,
      completedJobs: 19,
      responseRate: 91,
      badges: ["fast_responder"],
      ratingAvg: 4.3,
      reviewsCount: 8
    },
    distanceKm: 5.2,
    etaMinutes: 15,
    fraudScore: 18,
    reported: false
  },
  {
    id: "job-5",
    title: "Maintenance Climatisation Centrale Inverter",
    category: "⚡ Électricité",
    categoryIcon: "⚡",
    price: 60000,
    currency: "XAF",
    phone: "+237670112233",
    landmark: "Omnisports, Proche du Stade",
    city: "Yaoundé",
    desc: "Entretien annuel de 4 splits inverter LG de 2 CV : recharge en gaz R410A, nettoyage des filtres à charbon, et traitement antifongique des bacs à condensats.",
    images: [
      "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=600&q=80"
    ],
    lat: 3.886,
    lng: 11.536,
    timestamp: Date.now() - 2000,
    status: 'open',
    verified: true,
    provider: {
      uid: "usr-55",
      name: "Patrice KENFACK",
      avatar: "👨‍💻",
      role: "Frigoriste & Technicien Thermique",
      skills: ["Systèmes Inverter", "Fluides frigorigènes", "Diagnostic"],
      trustScore: 99,
      completedJobs: 83,
      responseRate: 100,
      badges: ["verified", "top_rated", "id_checked", "fast_responder"],
      ratingAvg: 5.0,
      reviewsCount: 56
    },
    distanceKm: 2.1,
    etaMinutes: 8,
    fraudScore: 2,
    reported: false
  }
];

export const MOCK_CHATS: Record<string, { sender: string; text: string; time: string; self: boolean }[]> = {
  "job-1": [
    { sender: "Ing. Marc FOMBA", text: "Bonjour, j'ai vu votre offre d'installation triphasée à Bastos. Je suis disponible immédiatement avec mon camion d'outillage.", time: "14:32", self: false },
    { sender: "Vous", text: "Super ! Est-ce que vous avez le matériel pour tester l'isolement des câbles ?", time: "14:35", self: true },
    { sender: "Ing. Marc FOMBA", text: "Oui, j'ai un mégohmmètre Fluke étalonné. Je peux être là dans 15 minutes max.", time: "14:36", self: false }
  ],
  "job-2": [
    { sender: "Amadou TCHANKOU", text: "Le bétonneur est prêt sur le site d'Akwa. Venez avec vos casques de protection.", time: "Hier", self: false },
    { sender: "Vous", text: "Entendu, toute l'équipe est en route.", time: "Hier", self: true }
  ]
};

export const MOCK_REVIEWS: Record<string, { reviewer: string; stars: number; comment: string; date: string }[]> = {
  "usr-99": [
    { reviewer: "Cabinet Médical Bastos", stars: 5, comment: "Excellent travail sur notre onduleur de secours. Très minutieux et ponctuel.", date: "10 Janv 2026" },
    { reviewer: "Villa 42-B", stars: 5, comment: "Recommandé à 100%. Il a repéré une anomalie de terre dangereuse et l'a réparée directement.", date: "28 Déc 2025" }
  ],
  "usr-88": [
    { reviewer: "SCDP Promoteur", stars: 4, comment: "Dalle coulée proprement en un temps record. Respecte les dosages de ciment.", date: "15 Janv 2026" }
  ]
};
