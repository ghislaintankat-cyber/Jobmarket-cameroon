import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Search, 
  PlusCircle, 
  User, 
  MessageSquare, 
  ShieldCheck, 
  CheckCircle2, 
  Award, 
  AlertTriangle, 
  Languages, 
  Globe, 
  Sliders, 
  Star, 
  Volume2, 
  Briefcase, 
  CheckCircle,
  Lock,
  Zap,
  Info
} from 'lucide-react';
import { INITIAL_JOBS, Job, MOCK_CHATS } from './data/mockJobs';

export default function App() {
  // --- Core Architecture States ---
  const [jobs, setJobs] = useState<Job[]>(INITIAL_JOBS);
  const [selectedJob, setSelectedJob] = useState<Job | null>(INITIAL_JOBS[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  
  // Advanced Filter Settings
  const [minPrice, setMinPrice] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(1000000);
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [maxDistance, setMaxDistance] = useState<number>(20);
  const [sortBy, setSortBy] = useState<'distance' | 'priceAsc' | 'priceDesc' | 'trustScore'>('distance');

  // Navigation / Drawer views
  const [currentTab, setCurrentTab] = useState<'map' | 'feed' | 'chat' | 'profile' | 'admin'>('feed');
  const [showPostDrawer, setShowPostDrawer] = useState(false);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  // Internationalization & Configuration Layer
  const [language, setLanguage] = useState<'fr' | 'en'>('fr');
  const [country, setCountry] = useState('Cameroon');
  const [currency, setCurrency] = useState('XAF');

  // Interactive Security Throttling & Cooldowns
  const [spamCooldown, setSpamCooldown] = useState<number>(0);
  const [isEmailVerified] = useState(true);
  const [userVerificationLevel, setUserVerificationLevel] = useState<'Premium Verified' | 'Basic ID Checked' | 'Unverified'>('Premium Verified');
  const [mySkills, setMySkills] = useState<string[]>(["Plomberie PPR", "Soudure à l'arc", "Électricité domestique"]);
  const [newSkillText, setNewSkillText] = useState('');

  // Secure In-App Messaging State
  const [chats, setChats] = useState(MOCK_CHATS);
  const [activeChatJobId, setActiveChatJobId] = useState<string>("job-1");
  const [typedMessage, setTypedMessage] = useState('');

  // Saved / Favorite Jobs Set
  const [savedJobIds, setSavedJobIds] = useState<Set<string>>(new Set(["job-2"]));

  // Form Posting State
  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState('⚡ Électricité');
  const [formPrice, setFormPrice] = useState('');
  const [formLandmark, setFormLandmark] = useState('');
  const [formPhone, setFormPhone] = useState('+237 ');
  const [formDesc, setFormDesc] = useState('');
  const [formCity, setFormCity] = useState('Yaoundé');
  const [uploadedImagesPreview, setUploadedImagesPreview] = useState<string[]>([
    "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=400&q=80"
  ]);

  // Voice navigation voice synthesis state
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Admin Dashboard States
  const [adminDisputes, setAdminDisputes] = useState([
    { id: "disp-1", jobId: "job-3", title: "Divergence tarifaire Bonapriso", reporter: "Client Samuel", reason: "Artisan réclame un supplément non convenu de 10,000 XAF", status: "En attente" },
  ]);
  const [systemLogs, setSystemLogs] = useState<string[]>([
    "Pare-feu Anti-Spam activé",
    "Analyse de fraude IA : 0 anomalies critiques détectées",
    "Indexation CDN Cloudinary opérationnelle"
  ]);

  // Anti-Spam Timer tick down
  useEffect(() => {
    if (spamCooldown > 0) {
      const timer = setTimeout(() => setSpamCooldown(spamCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [spamCooldown]);

  // Handle Voice Announcement Itinerary trigger
  const triggerVoiceItinerary = (job: Job) => {
    const text = language === 'fr' 
      ? `Itinéraire vers ${job.title} à ${job.landmark}. Distance estimée à ${job.distanceKm} kilomètres. Temps de parcours estimé à ${job.etaMinutes} minutes via axe principal.`
      : `Route optimization to ${job.title} at ${job.landmark}. Distance is ${job.distanceKm} kilometers. Estimated time of arrival is ${job.etaMinutes} minutes.`;
    
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = language === 'fr' ? 'fr-FR' : 'en-US';
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } else {
      setIsSpeaking(true);
      setTimeout(() => setIsSpeaking(false), 3000);
    }
  };

  // Toggle favorite
  const toggleSaveJob = (id: string) => {
    const next = new Set(savedJobIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSavedJobIds(next);
  };

  // Handle Submit Job Form
  const handleCreateJob = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle || !formPrice) {
      alert(language === 'fr' ? "Veuillez remplir le titre et le budget." : "Please fill title and budget.");
      return;
    }

    if (spamCooldown > 0) {
      alert(language === 'fr' ? `Sécurité Anti-Spam active. Veuillez patienter ${spamCooldown}s.` : `Anti-spam cooldown active. Wait ${spamCooldown}s.`);
      return;
    }

    // AI Simulated Fraud Assessment based on keywords & phone format
    let calculatedFraudScore = 2;
    if (formDesc.toLowerCase().includes("argent gratuit") || formDesc.toLowerCase().includes("gagner vite") || Number(formPrice) > 5000000) {
      calculatedFraudScore = 78; // High risk trigger
    }

    const newJob: Job = {
      id: `job-${Date.now()}`,
      title: formTitle,
      category: formCategory,
      categoryIcon: formCategory.split(' ')[0],
      price: parseFloat(formPrice) || 25000,
      currency: currency,
      phone: formPhone,
      landmark: formLandmark || "Quartier Central",
      city: formCity,
      desc: formDesc,
      images: uploadedImagesPreview,
      lat: 3.84 + Math.random() * 0.05,
      lng: 11.50 + Math.random() * 0.05,
      timestamp: Date.now(),
      status: 'open',
      verified: userVerificationLevel !== 'Unverified',
      provider: {
        uid: "usr-current",
        name: "Vous (" + (userVerificationLevel) + ")",
        avatar: "👑",
        role: "Artisan Certifié de l'Écosystème",
        skills: mySkills,
        trustScore: 96,
        completedJobs: 14,
        responseRate: 100,
        badges: ["verified", "id_checked"],
        ratingAvg: 4.8,
        reviewsCount: 4
      },
      distanceKm: parseFloat((1 + Math.random() * 8).toFixed(1)),
      etaMinutes: Math.round(5 + Math.random() * 15),
      fraudScore: calculatedFraudScore,
      reported: false
    };

    setJobs([newJob, ...jobs]);
    setSelectedJob(newJob);
    
    // Clear & activate anti-spam safety
    setFormTitle('');
    setFormPrice('');
    setFormLandmark('');
    setFormDesc('');
    setShowPostDrawer(false);
    setSpamCooldown(30); // 30 seconds protection cooldown

    // Log the event into state-based analytics log
    setSystemLogs([`Nouveau job créé [${newJob.title}] - Score Fraude calculé: ${calculatedFraudScore}%`, ...systemLogs]);
    
    // Notify with voice simulation
    if ('speechSynthesis' in window) {
      const msg = new SpeechSynthesisUtterance(language === 'fr' ? "Job publié avec succès sur Job Market Pro Max" : "Job successfully published");
      msg.lang = language === 'fr' ? 'fr-FR' : 'en-US';
      window.speechSynthesis.speak(msg);
    }
  };

  // Report job for moderation review
  const reportJob = (id: string, reason: string) => {
    setJobs(jobs.map(j => j.id === id ? { ...j, reported: true, reportReason: reason, fraudScore: Math.min(j.fraudScore + 40, 100) } : j));
    setSystemLogs([`Alerte Utilisateur: Signalement initié pour le Job ${id}. Motif: ${reason}`, ...systemLogs]);
    alert(language === 'fr' ? "Signalement envoyé aux modérateurs de JobMarket Cameroon PRO MAX." : "Report logged into moderation stream.");
  };

  // Send interactive message
  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedMessage.trim()) return;

    const existingChat = chats[activeChatJobId] || [];
    const updatedChat = [
      ...existingChat,
      { sender: "Vous", text: typedMessage, time: "À l'instant", self: true }
    ];

    setChats({
      ...chats,
      [activeChatJobId]: updatedChat
    });
    setTypedMessage('');

    // Simulate auto response after 2 seconds
    setTimeout(() => {
      const targetedJob = jobs.find(j => j.id === activeChatJobId);
      const name = targetedJob ? targetedJob.provider.name : "Prestataire";
      setChats(prev => ({
        ...prev,
        [activeChatJobId]: [
          ...(prev[activeChatJobId] || []),
          { sender: name, text: "Bien reçu ! Votre profil m'intéresse. Continuons la discussion ou appelez-moi.", time: "À l'instant", self: false }
        ]
      }));
    }, 2000);
  };

  // Filter & Search Logic
  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          job.desc.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          job.landmark.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          job.provider.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || job.category.includes(selectedCategory) || job.categoryIcon === selectedCategory;
    const matchesVerified = !verifiedOnly || job.verified || job.provider.badges.includes('verified');
    const matchesPrice = job.price >= minPrice && job.price <= maxPrice;
    const matchesDistance = job.distanceKm <= maxDistance;

    return matchesSearch && matchesCategory && matchesVerified && matchesPrice && matchesDistance;
  }).sort((a, b) => {
    if (sortBy === 'distance') return a.distanceKm - b.distanceKm;
    if (sortBy === 'priceAsc') return a.price - b.price;
    if (sortBy === 'priceDesc') return b.price - a.price;
    if (sortBy === 'trustScore') return b.provider.trustScore - a.provider.trustScore;
    return 0;
  });

  // Dynamic status color helper
  const getStatusBadgeColor = (status: string) => {
    switch(status) {
      case 'open': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'in_progress': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'completed': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans selection:bg-amber-400 selection:text-slate-900 overflow-x-hidden">
      
      {/* GLOBAL PWA TOP STATUS & SECURITY COMPLIANCE TIMER BANNER */}
      <div className="bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-slate-950 px-4 py-2 text-xs font-bold flex flex-wrap justify-between items-center gap-2 shadow-inner">
        <div className="flex items-center gap-2">
          <span className="bg-black text-amber-400 text-[10px] px-1.5 py-0.5 rounded-full animate-pulse">PRO MAX v4.2</span>
          <span>🇨🇲 {language === 'fr' ? 'Super-App Emploi & Services à Haute Précision' : 'High-Precision Labor Super-App'}</span>
        </div>
        <div className="flex items-center gap-4">
          {spamCooldown > 0 && (
            <span className="bg-red-600 text-white px-2 py-0.5 rounded text-[10px] uppercase tracking-wider animate-bounce">
              ⚠️ Anti-Spam Cooldown: {spamCooldown}s
            </span>
          )}
          <span className="opacity-90 hidden sm:inline">⚡ Cloudinary CDN Optimized • PWA Offline Ready</span>
          <div className="flex items-center gap-1 bg-amber-700/20 px-2 py-0.5 rounded text-[11px]">
            <Lock className="w-3 h-3 text-emerald-950" />
            <span>AES-256 Chats</span>
          </div>
        </div>
      </div>

      {/* CORE PLATFORM MASTER APP BAR */}
      <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 px-4 py-3 shadow-xl">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Logo & Platform Pitch */}
          <div className="flex items-center justify-between w-full md:w-auto gap-4">
            <div className="flex items-center gap-2">
              <div className="bg-amber-400 p-2 rounded-xl text-slate-950 font-black tracking-tighter text-xl shadow-lg shadow-amber-400/10 flex items-center gap-1">
                <Zap className="w-5 h-5 fill-current text-slate-950" />
                <span>JobMarket</span>
              </div>
              <div className="leading-none">
                <span className="text-xs uppercase tracking-widest text-amber-400 font-black block">Cameroon</span>
                <span className="text-[10px] text-slate-400">Competitive Architecture</span>
              </div>
            </div>

            {/* Quick Trigger for Post on Mobile */}
            <button 
              onClick={() => setShowPostDrawer(true)}
              className="md:hidden bg-amber-400 text-slate-950 px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1 active:scale-95 transition-transform"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Publier</span>
            </button>
          </div>

          {/* Core App Navigation Tabs Tabs Bar */}
          <nav className="flex items-center bg-slate-850 p-1 rounded-xl border border-slate-800 text-sm w-full md:w-auto overflow-x-auto whitespace-nowrap">
            <button 
              onClick={() => setCurrentTab('feed')}
              className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-2 ${currentTab === 'feed' ? 'bg-amber-400 text-slate-900 shadow' : 'text-slate-300 hover:text-white'}`}
            >
              <Briefcase className="w-4 h-4" />
              <span>{language === 'fr' ? 'Flux des Jobs' : 'Job Feed'}</span>
              <span className="bg-slate-700 text-white text-[10px] px-1.5 py-0.2 rounded-full font-mono">{filteredJobs.length}</span>
            </button>

            <button 
              onClick={() => setCurrentTab('map')}
              className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-2 ${currentTab === 'map' ? 'bg-amber-400 text-slate-900 shadow' : 'text-slate-300 hover:text-white'}`}
            >
              <MapPin className="w-4 h-4" />
              <span>{language === 'fr' ? 'Précision GPS Map' : 'GPS Precise Map'}</span>
            </button>

            <button 
              onClick={() => setCurrentTab('chat')}
              className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-2 relative ${currentTab === 'chat' ? 'bg-amber-400 text-slate-900 shadow' : 'text-slate-300 hover:text-white'}`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>{language === 'fr' ? 'Messagerie Secure' : 'Secure Messenger'}</span>
              <span className="absolute top-0 right-0 w-2 h-2 bg-emerald-400 rounded-full animate-ping"></span>
            </button>

            <button 
              onClick={() => setCurrentTab('profile')}
              className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-2 ${currentTab === 'profile' ? 'bg-amber-400 text-slate-900 shadow' : 'text-slate-300 hover:text-white'}`}
            >
              <User className="w-4 h-4" />
              <span>{language === 'fr' ? 'Mon Compte LinkedIn' : 'Reputation Score'}</span>
              {userVerificationLevel === 'Premium Verified' && <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />}
            </button>

            <button 
              onClick={() => setCurrentTab('admin')}
              className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-2 ${currentTab === 'admin' ? 'bg-purple-500 text-white shadow' : 'text-purple-300 hover:text-purple-100'}`}
            >
              <Award className="w-4 h-4" />
              <span>{language === 'fr' ? 'Dashboard Admin' : 'Admin Hub'}</span>
            </button>
          </nav>

          {/* Country / Currency / Language Localization Selectors Engine */}
          <div className="flex items-center gap-2 text-xs self-stretch justify-end md:self-auto">
            
            {/* Language Toggle */}
            <div className="bg-slate-800 rounded-lg p-1 flex items-center gap-1 border border-slate-700">
              <Languages className="w-3.5 h-3.5 text-slate-400 ml-1" />
              <select 
                value={language} 
                onChange={(e) => setLanguage(e.target.value as 'fr' | 'en')}
                className="bg-transparent text-slate-200 outline-none pr-1 cursor-pointer font-semibold font-mono"
              >
                <option value="fr" className="bg-slate-800 text-slate-200">FR</option>
                <option value="en" className="bg-slate-800 text-slate-200">EN</option>
              </select>
            </div>

            {/* Country Selector */}
            <div className="bg-slate-800 rounded-lg p-1 flex items-center gap-1 border border-slate-700">
              <Globe className="w-3.5 h-3.5 text-slate-400 ml-1" />
              <select 
                value={country} 
                onChange={(e) => {
                  setCountry(e.target.value);
                  if(e.target.value === 'Nigeria') setCurrency('NGN');
                  else if(e.target.value === 'Cameroon' || e.target.value === 'Gabon') setCurrency('XAF');
                }}
                className="bg-transparent text-slate-200 outline-none pr-1 cursor-pointer font-semibold"
              >
                <option value="Cameroon" className="bg-slate-800">Cameroun 🇨🇲</option>
                <option value="Nigeria" className="bg-slate-800">Nigeria 🇳🇬</option>
                <option value="Gabon" className="bg-slate-800">Gabon 🇬🇦</option>
                <option value="Côte d'Ivoire" className="bg-slate-800">RCI 🇨🇮</option>
              </select>
            </div>

            {/* Currency Selector */}
            <div className="bg-slate-800 rounded-lg p-1 flex items-center gap-1 border border-slate-700">
              <span className="text-amber-400 font-mono font-bold ml-1">$</span>
              <select 
                value={currency} 
                onChange={(e) => setCurrency(e.target.value)}
                className="bg-transparent text-slate-200 outline-none pr-1 cursor-pointer font-mono font-semibold"
              >
                <option value="XAF" className="bg-slate-800">FCFA (XAF)</option>
                <option value="NGN" className="bg-slate-800">Naira (NGN)</option>
                <option value="USD" className="bg-slate-800">USD ($)</option>
              </select>
            </div>

            {/* Desktop Publish Button */}
            <button 
              onClick={() => setShowPostDrawer(true)} 
              className="hidden md:flex bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 px-4 py-2 rounded-xl font-extrabold items-center gap-1.5 transition-all shadow-md shadow-amber-400/10 active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{language === 'fr' ? 'Publier un Job' : 'Instant Post'}</span>
            </button>
          </div>

        </div>
      </header>

      {/* SEARCH AND QUICK CATEGORY CAROUSEL BLOCK (GLOVO / JUMIA STYLE FAST BROWSING) */}
      <section className="bg-slate-900 border-b border-slate-800 py-4 px-4 shadow-md">
        <div className="max-w-7xl mx-auto space-y-3">
          
          {/* Advanced Main Search Bar with Slide filter switch */}
          <div className="flex flex-col sm:flex-row items-stretch gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
              <input 
                type="text" 
                placeholder={language === 'fr' ? "Rechercher par métier, repère (Bastos, Akwa...), mot-clé ou prestataire..." : "Search by craft, landmark, keyword..."}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-12 pr-4 py-3 text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs bg-slate-700 hover:bg-slate-600 text-slate-300 px-2 py-1 rounded"
                >
                  Effacer
                </button>
              )}
            </div>

            <button 
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className={`px-4 py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 border transition-all ${showAdvancedFilters ? 'bg-amber-400 text-slate-900 border-amber-400' : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'}`}
            >
              <Sliders className="w-4 h-4" />
              <span>{language === 'fr' ? 'Filtres Avancés Uber' : 'Uber Precision Filters'}</span>
              {(verifiedOnly || minPrice > 0 || maxPrice < 1000000 || maxDistance < 20) && (
                <span className="w-2.5 h-2.5 bg-red-500 rounded-full"></span>
              )}
            </button>
          </div>

          {/* EXPANDABLE UBER-PRECISION SLIDERS PANEL */}
          {showAdvancedFilters && (
            <div className="bg-slate-850 border border-slate-700/60 rounded-xl p-4 grid grid-cols-1 md:grid-cols-4 gap-4 text-xs animate-fadeIn">
              
              {/* Distance radius constraint */}
              <div className="space-y-1.5">
                <div className="flex justify-between font-bold">
                  <span className="text-slate-300 flex items-center gap-1">📍 Distance Maximale (Uber Live):</span>
                  <span className="text-amber-400 font-mono">{maxDistance} km</span>
                </div>
                <input 
                  type="range" 
                  min="1" 
                  max="50" 
                  value={maxDistance} 
                  onChange={(e) => setMaxDistance(Number(e.target.value))}
                  className="w-full accent-amber-400 bg-slate-700 rounded-lg appearance-none h-2 cursor-pointer" 
                />
                <p className="text-[10px] text-slate-400">Tri en temps réel selon votre position GPS simulée.</p>
              </div>

              {/* Price Range Constraint */}
              <div className="space-y-1.5 col-span-1 md:col-span-2">
                <div className="flex justify-between font-bold">
                  <span className="text-slate-300">💰 Budget Range ({currency}):</span>
                  <span className="text-amber-400 font-mono">{minPrice.toLocaleString()} - {maxPrice.toLocaleString()} {currency}</span>
                </div>
                <div className="flex items-center gap-2">
                  <input 
                    type="number" 
                    placeholder="Min" 
                    value={minPrice || ''} 
                    onChange={(e) => setMinPrice(Number(e.target.value))}
                    className="w-1/2 bg-slate-800 border border-slate-700 rounded px-2 py-1 text-slate-200"
                  />
                  <input 
                    type="number" 
                    placeholder="Max" 
                    value={maxPrice === 1000000 ? '' : maxPrice} 
                    onChange={(e) => setMaxPrice(e.target.value ? Number(e.target.value) : 1000000)}
                    className="w-1/2 bg-slate-800 border border-slate-700 rounded px-2 py-1 text-slate-200"
                  />
                </div>
              </div>

              {/* LinkedIn Badges Only Check */}
              <div className="space-y-2 flex flex-col justify-between">
                <label className="flex items-center gap-2 text-slate-300 font-bold cursor-pointer pt-2">
                  <input 
                    type="checkbox" 
                    checked={verifiedOnly}
                    onChange={(e) => setVerifiedOnly(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-500 accent-amber-400 bg-slate-800 border-slate-700 focus:ring-0"
                  />
                  <div className="leading-tight">
                    <span className="block text-slate-200">Badges de Confiance LinkedIn</span>
                    <span className="text-[10px] text-slate-400 block font-normal">Prestataires vérifiés uniquement</span>
                  </div>
                </label>

                {/* Sort selector */}
                <div className="flex items-center gap-1.5 bg-slate-800 px-2 py-1 rounded border border-slate-700">
                  <span className="text-slate-400 text-[10px]">Tri:</span>
                  <select 
                    value={sortBy} 
                    onChange={(e: any) => setSortBy(e.target.value)}
                    className="bg-transparent text-slate-200 font-bold focus:outline-none w-full"
                  >
                    <option value="distance" className="bg-slate-800">Proximité GPS</option>
                    <option value="trustScore" className="bg-slate-800">Score de Confiance</option>
                    <option value="priceAsc" className="bg-slate-800">Budget croissant</option>
                    <option value="priceDesc" className="bg-slate-800">Budget décroissant</option>
                  </select>
                </div>
              </div>

            </div>
          )}

          {/* FAST CATEGORY BROWSING CAROUSEL (GLOVO / JUMIA APPS MODEL) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin scrollbar-thumb-slate-700">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider whitespace-nowrap mr-1">
              {language === 'fr' ? 'Catégories:' : 'Categories:'}
            </span>
            {[
              { label: language === 'fr' ? 'Tous les Jobs' : 'All Jobs', val: 'all', icon: '🌍' },
              { label: '🔧 BTP & Rénovation', val: '🔧', icon: '🔧' },
              { label: '⚡ Électricité & Énergie', val: '⚡', icon: '⚡' },
              { label: '💧 Plomberie & Fuites', val: '💧', icon: '💧' },
              { label: '🧹 Ménage & Nettoyage', val: '🧹', icon: '🧹' }
            ].map((cat) => {
              const isActive = selectedCategory === cat.val;
              return (
                <button
                  key={cat.val}
                  onClick={() => setSelectedCategory(cat.val)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap transform active:scale-95 ${isActive ? 'bg-amber-400 text-slate-950 shadow-md font-extrabold scale-105' : 'bg-slate-800 text-slate-300 hover:bg-slate-750'}`}
                >
                  <span>{cat.icon}</span>
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>

        </div>
      </section>

      {/* MAIN LAYOUT SPLIT - INTERACTIVE MAP OR LIST DEPENDING ON TAB OR SIDE-BY-SIDE ON DESKTOP */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        
        {/* EMAIL VERIFICATION SIMULATOR WARNING INDICATOR */}
        {isEmailVerified && (
          <div className="mb-6 bg-slate-800/80 border-l-4 border-emerald-500 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-400">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-200">
                  {language === 'fr' ? 'Profil Validé & Sécurisé' : 'Identity Stream Secure'}
                </h4>
                <p className="text-xs text-slate-400">
                  {language === 'fr' 
                    ? "Votre adresse email est vérifiée. Votre score de réputation LinkedIn local augmente de +15 points automatiquement." 
                    : "Your email is verified. Local reputation score increases by +15 points."}
                </p>
              </div>
            </div>
            <div className="text-xs bg-slate-700 px-3 py-1 rounded-lg text-slate-300 font-mono">
              Statut: {userVerificationLevel}
            </div>
          </div>
        )}

        {/* CONTROLLABLE WORKSPACE TABS GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* LEFT & CENTER PORTION: DYNAMIC ACCORDING TO USER NAVIGATION */}
          
          {/* TAB: FEED VIEW OR SIDE GRID INTERACTION */}
          <div className={`space-y-4 ${currentTab === 'feed' || currentTab === 'map' ? 'lg:col-span-7' : 'hidden'}`}>
            
            {/* If MAP subtab is toggled on small screens or we show it dynamically */}
            {currentTab === 'map' && (
              <div className="bg-slate-850 rounded-2xl border border-slate-700 overflow-hidden shadow-2xl relative">
                
                {/* UBER/BOLT SATELLITE SIMULATION PANEL HEADER */}
                <div className="bg-slate-800 p-3 px-4 border-b border-slate-700 flex justify-between items-center text-xs">
                  <div className="flex items-center gap-2 text-amber-400 font-bold">
                    <span className="w-2 h-2 bg-red-500 rounded-full animate-ping"></span>
                    <span>UBER PRECISION SATELLITE GPS ACTIVE</span>
                  </div>
                  <span className="text-slate-400 font-mono">Douala/Yaoundé Grid Sync: 100%</span>
                </div>

                {/* SATELLITE CANVAS SIMULATION COMPONENT */}
                <div className="h-96 w-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-800 via-slate-900 to-black relative p-4 flex flex-col justify-between overflow-hidden">
                  
                  {/* Pseudo-Satellite Grid Vectors lines overlay */}
                  <div className="absolute inset-0 opacity-10 pointer-events-none bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:24px_24px]"></div>
                  
                  {/* Satellite Radar Sweeper circle effect */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full border border-amber-400/20 animate-pulse pointer-events-none"></div>

                  {/* Simulated Center User Location Pin */}
                  <div className="absolute top-1/3 left-1/3 bg-blue-500 text-white p-2 rounded-full shadow-2xl shadow-blue-500/50 flex flex-col items-center group z-10">
                    <div className="w-3 h-3 bg-white rounded-full animate-ping absolute top-0"></div>
                    <span className="text-[10px] font-black bg-slate-900 px-1 py-0.2 rounded whitespace-nowrap absolute -top-6">
                      📍 {language === 'fr' ? 'Moi (Votre GPS)' : 'My GPS Coords'}
                    </span>
                  </div>

                  {/* Simulated Job Markers on Map canvas */}
                  {filteredJobs.map((job, idx) => {
                    const offsetLat = (idx * 30) + 40;
                    const offsetLng = (idx * 45) + 60;
                    const isCurrentSelected = selectedJob?.id === job.id;
                    
                    return (
                      <button
                        key={job.id}
                        onClick={() => setSelectedJob(job)}
                        className="absolute bg-slate-950/90 hover:bg-slate-900 border text-xs p-1.5 rounded-lg shadow-xl flex items-center gap-1 text-left transition-all hover:scale-105 z-20"
                        style={{ top: `${(offsetLat % 75) + 15}%`, left: `${(offsetLng % 70) + 20}%`, borderColor: isCurrentSelected ? '#fbbf24' : '#475569' }}
                      >
                        <span className="text-sm">{job.categoryIcon}</span>
                        <div>
                          <p className="font-bold text-[10px] truncate w-24 text-slate-100">{job.title}</p>
                          <div className="flex justify-between text-[9px] text-slate-400 gap-2">
                            <span className="text-amber-400 font-bold">{job.price.toLocaleString()} {currency}</span>
                            <span>⏱️ {job.distanceKm}km</span>
                          </div>
                        </div>
                      </button>
                    );
                  })}

                  {/* INLINE UBER ROUTE OPTIMIZATION & ETA OVERLAY CAROUSEL */}
                  {selectedJob && (
                    <div className="mt-auto bg-slate-900/95 border border-amber-400/40 rounded-xl p-3 z-30 shadow-2xl animate-slideUp">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="bg-amber-400/20 text-amber-300 text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider block w-max mb-1">
                            Calcul d'itinéraire Uber / Bolt optimisé
                          </span>
                          <h5 className="text-xs font-bold text-white line-clamp-1">{selectedJob.title}</h5>
                          <p className="text-[11px] text-slate-400">
                            📍 {selectedJob.landmark} • <span className="text-slate-200 font-bold font-mono">{selectedJob.distanceKm} km</span> de distance réelle
                          </p>
                        </div>
                        <div className="text-right whitespace-nowrap bg-slate-800 p-1.5 rounded-lg border border-slate-700">
                          <span className="text-[10px] text-slate-400 block uppercase font-mono">ETA Estimé</span>
                          <span className="text-sm font-black text-emerald-400 font-mono">{selectedJob.etaMinutes} min</span>
                        </div>
                      </div>

                      {/* Voice Announcement Button Synthesizer */}
                      <div className="mt-2 pt-2 border-t border-slate-800 flex items-center justify-between text-[11px]">
                        <button 
                          onClick={() => triggerVoiceItinerary(selectedJob)}
                          className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors ${isSpeaking ? 'bg-red-900 text-white font-bold animate-pulse' : 'bg-amber-400 text-slate-950 font-bold hover:bg-amber-500'}`}
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>{isSpeaking ? (language === 'fr' ? 'Lecture Voix...' : 'Speaking...') : (language === 'fr' ? 'Lancer Itinéraire Vocal' : 'Play Voice Itinerary')}</span>
                        </button>
                        
                        <a 
                          href={`https://wa.me/${selectedJob.phone.replace(/[^0-9+]/g, '')}?text=Bonjour%20j'ai%20vu%20votre%2520annonce%20sur%20JobMarket%20PRO%20MAX%20:%20${encodeURIComponent(selectedJob.title)}`}
                          target="_blank" 
                          rel="noreferrer"
                          className="bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1 rounded font-bold flex items-center gap-1 transition-all"
                        >
                          <span>💬 WhatsApp Express</span>
                        </a>
                      </div>
                    </div>
                  )}

                  {/* Floating Map Help instructions */}
                  <div className="absolute top-2 right-2 bg-slate-900/90 text-[10px] text-slate-400 p-2 rounded border border-slate-800 max-w-[160px] pointer-events-none">
                    💡 Cliquez sur un marqueur de job pour synchroniser la trajectoire et l'ETA.
                  </div>

                </div>

                {/* Mobile tab reminder banner switcher */}
                <div className="p-3 bg-slate-850 text-center text-xs">
                  <button 
                    onClick={() => setCurrentTab('feed')} 
                    className="text-amber-400 hover:underline font-bold"
                  >
                    👉 {language === 'fr' ? 'Afficher la liste détaillée sous forme de cartes' : 'Switch back to high fidelity feed view'}
                  </button>
                </div>
              </div>
            )}

            {/* MAIN FEED: GRID LIST OF RELEVANT OPPORTUNITIES */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>{language === 'fr' ? 'Opportunités filtrées correspondantes' : 'Matching filtered requests'}</span>
                <span>{language === 'fr' ? 'Trié par' : 'Sorted by'}: <strong className="text-amber-400 font-mono">{sortBy}</strong></span>
              </div>

              {filteredJobs.length === 0 ? (
                <div className="bg-slate-850 rounded-2xl p-8 border border-slate-800 text-center space-y-3">
                  <AlertTriangle className="w-12 h-12 text-amber-400 mx-auto opacity-50" />
                  <h3 className="text-base font-bold text-slate-200">Aucun job trouvé à cette distance ou tarification</h3>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    Ajustez les curseurs Uber de rayon kilométrique ou effacez la barre de recherche textuelle pour rafraîchir les résultats.
                  </p>
                  <button 
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('all');
                      setMaxDistance(40);
                      setMinPrice(0);
                      setMaxPrice(1000000);
                      setVerifiedOnly(false);
                    }}
                    className="bg-slate-800 hover:bg-slate-700 text-white text-xs px-4 py-2 rounded-xl"
                  >
                    Réinitialiser tous les filtres
                  </button>
                </div>
              ) : (
                filteredJobs.map((job) => {
                  const isSelected = selectedJob?.id === job.id;
                  const isSaved = savedJobIds.has(job.id);
                  
                  return (
                    <div 
                      key={job.id}
                      onClick={() => setSelectedJob(job)}
                      className={`bg-slate-850 rounded-2xl p-4 border transition-all cursor-pointer hover:border-amber-400/60 relative ${isSelected ? 'ring-2 ring-amber-400 border-transparent bg-slate-800' : 'border-slate-800'}`}
                    >
                      {/* Top Badges & Meta */}
                      <div className="flex flex-wrap items-start justify-between gap-2 mb-2.5">
                        <div className="flex items-center gap-2">
                          <span className="bg-slate-900 px-2 py-1 rounded-lg font-bold text-xs text-slate-200 flex items-center gap-1 border border-slate-700">
                            <span>{job.categoryIcon}</span>
                            <span>{job.category.replace(/[^\u0000-\u007F]/g, '')}</span>
                          </span>
                          <span className={`text-[11px] font-mono border px-2 py-0.5 rounded-full uppercase font-bold ${getStatusBadgeColor(job.status)}`}>
                            {job.status === 'open' ? 'Ouvert 🟢' : job.status === 'in_progress' ? 'En Cours ⚡' : 'Clôturé 🔒'}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {/* Saved Toggle Icon */}
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleSaveJob(job.id);
                            }}
                            className={`p-1.5 rounded-lg transition-colors ${isSaved ? 'bg-amber-400/20 text-amber-400' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
                            title="Sauvegarder l'offre"
                          >
                            ★
                          </button>

                          {/* Anti-fraud AI danger badge indicator */}
                          {job.fraudScore > 20 && (
                            <span className="bg-red-950 border border-red-500/50 text-red-400 text-[10px] px-2 py-0.5 rounded font-mono font-bold animate-pulse">
                              ⚠️ Risque Fraude: {job.fraudScore}%
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Job Main Information */}
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
                        
                        {/* Thumbnail Cloudinary simulator image */}
                        {job.images && job.images.length > 0 && (
                          <div className="md:col-span-3 rounded-xl overflow-hidden bg-slate-900 h-24 relative group">
                            <img 
                              src={job.images[0]} 
                              alt="Job Gallery"
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform" 
                            />
                            <span className="absolute bottom-1 right-1 bg-black/70 px-1 text-[9px] text-white rounded">
                              +{job.images.length} pic
                            </span>
                          </div>
                        )}

                        {/* Title, description summary, budget */}
                        <div className={`${job.images && job.images.length > 0 ? 'md:col-span-9' : 'md:col-span-12'} space-y-1`}>
                          <h3 className="font-extrabold text-sm sm:text-base text-white hover:text-amber-300 transition-colors flex items-center gap-1.5">
                            {job.title}
                            {job.verified && <CheckCircle className="w-4 h-4 text-blue-400 shrink-0 fill-current" />}
                          </h3>

                          <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                            {job.desc}
                          </p>

                          {/* Uber live distance & location details bar */}
                          <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] text-slate-400">
                            <div className="flex items-center gap-1 text-slate-300">
                              <MapPin className="w-3.5 h-3.5 text-red-400 shrink-0" />
                              <span>{job.city} ({job.landmark})</span>
                            </div>
                            <div className="bg-slate-900 text-slate-300 px-2 py-0.5 rounded font-mono">
                              📏 <strong>{job.distanceKm} km</strong> d'ici
                            </div>
                            <div className="text-emerald-400 font-bold">
                              ⏱️ {job.etaMinutes} min ETA
                            </div>
                          </div>
                        </div>

                      </div>

                      {/* Double Sided Trust Provider Sub-card (LinkedIn Reputation Concept) */}
                      <div className="mt-3 pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900/40 p-2 rounded-xl">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-slate-800 border border-amber-400 flex items-center justify-center text-sm">
                            {job.provider.avatar}
                          </div>
                          <div>
                            <div className="flex items-center gap-1 text-xs">
                              <span className="font-bold text-slate-200">{job.provider.name}</span>
                              <span className="text-[10px] text-slate-400">({job.provider.role})</span>
                            </div>
                            <div className="flex items-center gap-2 text-[10px]">
                              <span className="text-amber-400 font-bold flex items-center gap-0.5">
                                <Star className="w-2.5 h-2.5 fill-current" /> {job.provider.ratingAvg} 
                              </span>
                              <span className="text-slate-400">({job.provider.completedJobs} {language === 'fr' ? 'jobs faits' : 'completed'})</span>
                              
                              {/* Trust Score badge */}
                              <span className="text-emerald-400 font-mono font-bold bg-emerald-950/80 px-1 rounded">
                                Score Confiance: {job.provider.trustScore}%
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Fast Action CTA buttons inside card */}
                        <div className="flex items-center gap-1 self-end sm:self-auto">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveChatJobId(job.id);
                              setCurrentTab('chat');
                            }}
                            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] px-2.5 py-1.5 rounded-lg font-bold flex items-center gap-1"
                          >
                            <MessageSquare className="w-3 h-3 text-amber-400" />
                            <span>{language === 'fr' ? 'Chat Sécurisé' : 'Secure Chat'}</span>
                          </button>
                          
                          <a 
                            href={`tel:${job.phone}`}
                            onClick={(e) => e.stopPropagation()}
                            className="bg-amber-400 hover:bg-amber-500 text-slate-950 font-black text-[11px] px-3 py-1.5 rounded-lg transition-all"
                          >
                            📞 Appeler
                          </a>
                        </div>
                      </div>

                    </div>
                  );
                })
              )}
            </div>

          </div>

          {/* TAB: SECURE INTERNAL CHAT MESSENGER (WHATSAPP/MESSENGER WITH USER PRESENCE) */}
          <div className={`space-y-4 lg:col-span-7 ${currentTab === 'chat' ? 'block' : 'hidden'}`}>
            <div className="bg-slate-850 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl flex flex-col h-[580px]">
              
              {/* Messenger Header with Real-Time Presence lights */}
              <div className="bg-slate-800 p-4 border-b border-slate-700 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-amber-400 rounded-full text-slate-950 font-black flex items-center justify-center text-lg shadow relative">
                    💬
                    <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-slate-800 rounded-full"></span>
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm sm:text-base text-slate-100 flex items-center gap-1.5">
                      {language === 'fr' ? 'Messagerie Interne Cryptée' : 'Internal Secure Message Desk'}
                    </h3>
                    <p className="text-xs text-emerald-400 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping"></span>
                      <span>{language === 'fr' ? 'Présence en ligne active • Serveur Douala' : 'Online Presence Activated'}</span>
                    </p>
                  </div>
                </div>

                <div className="bg-slate-900 px-2.5 py-1 rounded-lg text-[11px] border border-slate-700 text-slate-400">
                  🔒 Bout en bout AES
                </div>
              </div>

              {/* Chat Sub-selector Stream for active conversation threads */}
              <div className="p-2 bg-slate-900 border-b border-slate-800 flex items-center gap-2 overflow-x-auto">
                <span className="text-[11px] text-slate-400 uppercase font-mono tracking-wider pl-1 shrink-0">Conversations:</span>
                {jobs.slice(0, 4).map(j => (
                  <button 
                    key={j.id}
                    onClick={() => setActiveChatJobId(j.id)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${activeChatJobId === j.id ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300'}`}
                  >
                    👤 {j.provider.name.split(' ').pop()} ({j.categoryIcon})
                  </button>
                ))}
              </div>

              {/* Chat Messages Body Container */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-900/50 backdrop-blur-inner">
                <div className="text-center my-2">
                  <span className="bg-slate-800 text-slate-400 text-[10px] px-3 py-1 rounded-full uppercase tracking-widest border border-slate-700">
                    Début de l'historique sécurisé pour l'offre active
                  </span>
                </div>

                {(chats[activeChatJobId] || [
                  { sender: "Système", text: "Aucun message encore échangé. Lancez la discussion en posant vos questions sur les délais, les prix du matériel ou le lieu exact.", time: "Maintenant", self: false }
                ]).map((msg, mIdx) => (
                  <div key={mIdx} className={`flex flex-col ${msg.self ? 'items-end' : 'items-start'}`}>
                    <div className={`max-w-[85%] rounded-2xl p-3 text-xs shadow-md ${msg.self ? 'bg-blue-600 text-white rounded-tr-none' : 'bg-slate-800 text-slate-100 rounded-tl-none border border-slate-700'}`}>
                      <p className="font-bold text-[10px] mb-1 opacity-75">{msg.sender}</p>
                      <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                      <span className="block text-right text-[9px] opacity-60 mt-1 font-mono">{msg.time}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Media simulation sharing layer indicators */}
              <div className="px-4 py-1.5 bg-slate-800 text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-700">
                <span>📎 {language === 'fr' ? 'Partage de médias autorisé (De devis, photos avant/après)' : 'Media sharing enabled'}</span>
                <span className="text-amber-400 font-mono">Taille max: 15Mo</span>
              </div>

              {/* Interactive Send Input Form */}
              <form onSubmit={sendMessage} className="p-3 bg-slate-800 flex items-center gap-2">
                <input 
                  type="text"
                  value={typedMessage}
                  onChange={(e) => setTypedMessage(e.target.value)}
                  placeholder={language === 'fr' ? "Écrivez votre message sécurisé à l'artisan..." : "Type secure message..."}
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
                />
                <button 
                  type="submit"
                  className="bg-amber-400 hover:bg-amber-500 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs active:scale-95 transition-transform"
                >
                  {language === 'fr' ? 'Envoyer' : 'Send'}
                </button>
              </form>

            </div>
          </div>

          {/* TAB: LINKEDIN DETAILED PROFILE & TRUST METRICS SCORECARD */}
          <div className={`space-y-4 lg:col-span-7 ${currentTab === 'profile' ? 'block' : 'hidden'}`}>
            <div className="bg-slate-850 rounded-2xl border border-slate-800 p-6 space-y-6 shadow-2xl">
              
              {/* Profile Top Hero Banner */}
              <div className="text-center pb-4 border-b border-slate-800 relative">
                <div className="w-20 h-20 bg-gradient-to-tr from-amber-400 via-amber-500 to-yellow-600 rounded-full text-slate-950 font-black text-2xl flex items-center justify-center mx-auto shadow-xl ring-4 ring-slate-800">
                  JM
                </div>
                
                {/* Trust Badge Display */}
                <div className="mt-2 inline-flex items-center gap-1 bg-blue-500/20 text-blue-300 font-bold text-xs px-3 py-1 rounded-full border border-blue-500/40">
                  <ShieldCheck className="w-4 h-4 fill-current text-blue-400" />
                  <span>PRESTATAIRE VÉRIFIÉ LINKEDIN CORE API</span>
                </div>

                <h2 className="text-xl font-extrabold text-white mt-2">Utilisateur Pro Max Cameroon</h2>
                <p className="text-xs text-slate-400">Membre depuis Janvier 2026 • Localisation: Yaoundé/Douala Hub</p>
              </div>

              {/* Reputation & Analytics KPIs score numbers breakdown */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                  <span className="block text-xl font-mono font-black text-amber-400">98 / 100</span>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block mt-1">Reputation Score</span>
                </div>
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                  <span className="block text-xl font-mono font-black text-emerald-400">100%</span>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block mt-1">Taux de Réponse</span>
                </div>
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                  <span className="block text-xl font-mono font-black text-blue-400">24</span>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block mt-1">Missions Validées</span>
                </div>
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                  <span className="block text-xl font-mono font-black text-purple-400">5.0 ⭐</span>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block mt-1">Note Moyenne</span>
                </div>
              </div>

              {/* Verification layer state selector */}
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-700/60 space-y-3">
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                  <span>🛡️ Niveau de Vérification d'Identité Anti-Fraude</span>
                </h4>
                <p className="text-xs text-slate-400">
                  Augmentez votre visibilité sur la carte Uber/Bolt en changeant votre statut certifié d'autorité locale :
                </p>

                <div className="flex flex-col sm:flex-row gap-2 pt-1 text-xs">
                  {[
                    { level: 'Premium Verified', desc: 'CNI + Passeport + Justificatif (Visibilité +50%)', color: 'border-blue-500 text-blue-400' },
                    { level: 'Basic ID Checked', desc: 'Numéro de téléphone vérifié uniquement', color: 'border-amber-500 text-amber-400' },
                    { level: 'Unverified', desc: 'Anonyme (Soumis aux filtres de suspicion)', color: 'border-slate-700 text-slate-400' }
                  ].map(v => (
                    <button
                      key={v.level}
                      onClick={() => {
                        setUserVerificationLevel(v.level as any);
                        setSystemLogs([`Changement du niveau de vérification du profil vers : ${v.level}`, ...systemLogs]);
                      }}
                      className={`flex-1 p-2 rounded-lg border text-left transition-all ${userVerificationLevel === v.level ? 'bg-slate-800 border-2 font-bold ring-1 ring-amber-400' : 'bg-slate-950 opacity-60'}`}
                    >
                      <p className="font-bold text-[11px] block">{v.level}</p>
                      <p className="text-[10px] text-slate-400 font-normal mt-0.5">{v.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Skill based tags manager (LinkedIn Concept) */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  🎯 Mes Compétences Professionnelles Clés ({mySkills.length})
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {mySkills.map((sk, idx) => (
                    <span key={idx} className="bg-slate-800 text-amber-400 font-mono text-xs px-2.5 py-1 rounded-lg border border-slate-700 flex items-center gap-1">
                      <span>{sk}</span>
                      <button 
                        onClick={() => setMySkills(mySkills.filter(s => s !== sk))}
                        className="text-red-400 font-bold ml-1 hover:text-white"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>

                <div className="flex gap-2 pt-1">
                  <input 
                    type="text" 
                    placeholder="Ex: Soudure PPR, Climatisation LG, Peinture Époxy..."
                    value={newSkillText}
                    onChange={(e) => setNewSkillText(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-xs text-slate-100"
                  />
                  <button 
                    onClick={() => {
                      if(newSkillText.trim()) {
                        setMySkills([...mySkills, newSkillText.trim()]);
                        setNewSkillText('');
                      }
                    }}
                    className="bg-slate-700 hover:bg-slate-600 text-white text-xs px-3 py-1.5 rounded-lg"
                  >
                    Ajouter
                  </button>
                </div>
              </div>

              {/* Future Readiness Monetization Fields Toggle indicators */}
              <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 text-xs space-y-2">
                <h4 className="text-slate-300 font-bold flex items-center gap-1 text-[11px]">
                  <Info className="w-3.5 h-3.5 text-purple-400" />
                  <span>Architecture d'Expansion Internationale Préparée (Airbnb / Upwork ready)</span>
                </h4>
                <p className="text-slate-400 text-[11px]">
                  Les structures de séquestre (escrow), de commissions par virement mobile (Orange Money / MTN Mobile Money API), et de mise en avant premium sponsorisée sont injectées dans la base de données.
                </p>
                <div className="flex gap-2 text-[10px] text-slate-400 font-mono">
                  <span className="bg-slate-800 px-2 py-0.5 rounded">✔ fields.escrow_status = idle</span>
                  <span className="bg-slate-800 px-2 py-0.5 rounded">✔ fields.sponsored_weight = 1.0</span>
                </div>
              </div>

            </div>
          </div>

          {/* TAB: MODERATION ADMIN CENTER & REAL-TIME PLATFORM ANALYTICS */}
          <div className={`space-y-4 lg:col-span-7 ${currentTab === 'admin' ? 'block' : 'hidden'}`}>
            <div className="bg-slate-850 rounded-2xl border border-slate-800 p-6 space-y-6 shadow-2xl">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                <div>
                  <h3 className="text-lg font-black text-purple-400 flex items-center gap-2">
                    <span>🛡️ Centre d'Administration & Sécurité IA</span>
                  </h3>
                  <p className="text-xs text-slate-400">Modération en temps réel et infrastructure anti-fraude</p>
                </div>
                <div className="bg-purple-950 text-purple-300 px-2.5 py-1 rounded text-xs font-mono font-bold border border-purple-800">
                  UID d'administration: GrajEM98vOc1w3...
                </div>
              </div>

              {/* Visual Platform Metrics simulated indicators */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block">Total Jobs Indexés (MOCK DB)</span>
                  <span className="text-base font-mono font-black text-slate-100 block mt-1">{jobs.length} Annonces</span>
                  <div className="w-full bg-slate-800 h-1 rounded-full mt-2 overflow-hidden">
                    <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-full w-[70%]"></div>
                  </div>
                </div>

                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block">Signalements / Suspicion Fraude</span>
                  <span className="text-base font-mono font-black text-red-400 block mt-1">
                    {jobs.filter(j => j.reported || j.fraudScore > 30).length} Actifs
                  </span>
                  <div className="w-full bg-slate-800 h-1 rounded-full mt-2 overflow-hidden">
                    <div className="bg-red-500 h-full w-[25%]"></div>
                  </div>
                </div>

                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-400 block">Requêtes API CDN / Sec</span>
                  <span className="text-base font-mono font-black text-emerald-400 block mt-1">42 req/min</span>
                  <div className="w-full bg-slate-800 h-1 rounded-full mt-2 overflow-hidden">
                    <div className="bg-emerald-500 h-full w-[85%]"></div>
                  </div>
                </div>
              </div>

              {/* Active user reported job moderation row */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1">
                  <span>⚖️ File d'Attente des Litiges & Signalements Commençants</span>
                </h4>
                
                <div className="space-y-2">
                  {jobs.filter(j => j.reported || j.fraudScore > 20).map(j => (
                    <div key={j.id} className="bg-slate-900 p-3 rounded-xl border border-red-900/40 text-xs space-y-2">
                      <div className="flex justify-between items-start gap-2">
                        <div>
                          <p className="font-bold text-slate-200 text-xs">{j.title}</p>
                          <p className="text-[11px] text-slate-400">Posté par: {j.provider.name} • Score IA de suspicion: <strong className="text-red-400 font-mono">{j.fraudScore}%</strong></p>
                          {j.reported && <p className="text-amber-400 text-[11px] mt-1 italic">Raison signalée: "{j.reportReason || 'Non spécifiée'}"</p>}
                        </div>
                        <span className="bg-red-950 text-red-400 text-[10px] font-mono px-2 py-0.5 rounded">
                          À Revoir
                        </span>
                      </div>

                      <div className="flex items-center gap-2 pt-1 border-t border-slate-800 text-[11px]">
                        <button 
                          onClick={() => {
                            setJobs(jobs.map(item => item.id === j.id ? { ...item, fraudScore: 2, reported: false } : item));
                            setSystemLogs([`Admin: Réhabilitation du job ${j.id}. Blanchi de suspicion.`, ...systemLogs]);
                            alert("Le job a été blanchi avec succès.");
                          }}
                          className="bg-emerald-800 hover:bg-emerald-700 text-white px-2 py-1 rounded"
                        >
                          ✅ Blanchir / Approuver
                        </button>
                        <button 
                          onClick={() => {
                            setJobs(jobs.filter(item => item.id !== j.id));
                            setSystemLogs([`Admin: Suppression définitive de l'annonce frauduleuse ${j.id}`, ...systemLogs]);
                            alert("Annonce retirée définitivement du flux public.");
                          }}
                          className="bg-red-800 hover:bg-red-700 text-white px-2 py-1 rounded"
                        >
                          🗑️ Supprimer l'Annonce
                        </button>
                      </div>
                    </div>
                  ))}

                  {adminDisputes.map(disp => (
                    <div key={disp.id} className="bg-slate-900 p-3 rounded-xl border border-slate-800 text-xs space-y-1">
                      <div className="flex justify-between text-slate-300">
                        <strong className="text-amber-400">{disp.title}</strong>
                        <span className="bg-slate-800 text-slate-400 px-1.5 py-0.2 rounded text-[10px]">{disp.status}</span>
                      </div>
                      <p className="text-slate-400 text-[11px]">Signaleur: {disp.reporter} — {disp.reason}</p>
                      <button 
                        onClick={() => {
                          setAdminDisputes(adminDisputes.filter(d => d.id !== disp.id));
                          alert("Arbitrage complété. Notification push simulée transmise aux deux parties.");
                        }}
                        className="text-[10px] text-purple-400 font-bold hover:underline block pt-1"
                      >
                        ⚡ Résoudre le litige par remboursement séquestre
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Live Technical Action Logs Stream console */}
              <div className="space-y-1.5">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
                  📟 Journal Système des Événements (Live Telemetry):
                </h4>
                <div className="bg-slate-950 p-3 rounded-lg font-mono text-[11px] text-slate-300 space-y-1 max-h-36 overflow-y-auto">
                  {systemLogs.map((log, idx) => (
                    <div key={idx} className="flex items-start gap-1">
                      <span className="text-purple-400 shrink-0">[{new Date().toLocaleTimeString()}]</span>
                      <span className="text-slate-200">{log}</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>

          {/* RIGHT PORTION: SELECTED OPPORTUNITY SPOTLIGHT SIDEBAR PANEL */}
          {/* Always shown or serves as high-fidelity inspect panel */}
          <div className="lg:col-span-5 space-y-4">
            
            <div className="bg-slate-850 rounded-2xl border border-slate-700 p-5 space-y-4 shadow-xl sticky top-24">
              
              {selectedJob ? (
                <>
                  {/* Top Image Slideshow Simulator or main header */}
                  <div className="relative rounded-xl overflow-hidden h-44 bg-slate-900">
                    <img 
                      src={selectedJob.images?.[0] || "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=600&q=80"} 
                      alt={selectedJob.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent"></div>
                    
                    {/* Floating price sticker tag */}
                    <div className="absolute bottom-3 left-3 bg-slate-950/90 text-white px-3 py-1.5 rounded-xl border border-amber-400 font-mono text-sm font-black tracking-tight">
                      {selectedJob.price.toLocaleString()} <span className="text-amber-400">{selectedJob.currency}</span>
                    </div>

                    <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] text-slate-300 font-mono">
                      🌟 {selectedJob.provider.trustScore}% Trust
                    </div>
                  </div>

                  {/* Title & Core Meta */}
                  <div className="space-y-1">
                    <div className="text-xs text-amber-400 font-bold uppercase tracking-wider flex items-center gap-1">
                      <span>{selectedJob.category}</span>
                      <span>•</span>
                      <span>{selectedJob.city}</span>
                    </div>
                    
                    <h2 className="text-lg font-black text-white leading-tight">
                      {selectedJob.title}
                    </h2>

                    <p className="text-xs text-slate-400 flex items-center gap-1">
                      <span>Posté il y a quelques heures</span>
                      <span>•</span>
                      <span className="text-slate-300 font-bold">📍 {selectedJob.landmark}</span>
                    </p>
                  </div>

                  {/* Uber / Bolt Realtime Proximity Info Panel widget */}
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-700/70 text-xs space-y-2">
                    <div className="flex justify-between items-center text-[11px] text-slate-400 uppercase tracking-wide">
                      <span>Calculateur de Précision Uber / Bolt</span>
                      <span className="text-emerald-400 font-bold font-mono">GPS Sync Active</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-center">
                      <div className="bg-slate-800 p-2 rounded border border-slate-700">
                        <span className="text-[10px] text-slate-400 block">Distance de Vol</span>
                        <strong className="text-sm font-mono text-slate-100">{selectedJob.distanceKm} km</strong>
                      </div>
                      <div className="bg-slate-800 p-2 rounded border border-slate-700">
                        <span className="text-[10px] text-slate-400 block">Temps de Route (ETA)</span>
                        <strong className="text-sm font-mono text-amber-400">{selectedJob.etaMinutes} minutes</strong>
                      </div>
                    </div>

                    {/* Trigger audio guidance button */}
                    <button 
                      onClick={() => triggerVoiceItinerary(selectedJob)}
                      className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] py-1.5 rounded font-bold flex items-center justify-center gap-1"
                    >
                      <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                      <span>{language === 'fr' ? 'Écouter l\'itinéraire vocal optimisé' : 'Listen Voice optimized route'}</span>
                    </button>
                  </div>

                  {/* Complete Description */}
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      {language === 'fr' ? 'Détails de la mission :' : 'Job Details :'}
                    </h4>
                    <p className="text-xs text-slate-200 leading-relaxed bg-slate-900/60 p-3 rounded-xl border border-slate-800 whitespace-pre-wrap">
                      {selectedJob.desc}
                    </p>
                  </div>

                  {/* Double sided LinkedIn reputation info card */}
                  <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-700 space-y-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 bg-amber-400 rounded-full text-slate-950 font-black flex items-center justify-center text-base">
                        {selectedJob.provider.avatar}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-1">
                          <h4 className="text-xs font-bold text-slate-100">{selectedJob.provider.name}</h4>
                          {selectedJob.verified && <span className="bg-blue-500 text-white text-[8px] px-1 rounded-full uppercase font-black">ID Checked</span>}
                        </div>
                        <p className="text-[10px] text-slate-400 leading-tight">{selectedJob.provider.role}</p>
                      </div>
                    </div>

                    {/* Skills list tags for this provider */}
                    <div className="flex flex-wrap gap-1">
                      {selectedJob.provider.skills.map((sk, sIdx) => (
                        <span key={sIdx} className="bg-slate-800 text-slate-300 text-[10px] px-2 py-0.5 rounded font-mono">
                          {sk}
                        </span>
                      ))}
                    </div>

                    {/* Detailed Stars & reviews counters */}
                    <div className="bg-slate-800/80 p-2 rounded text-[11px] space-y-1.5 text-slate-300">
                      <div className="flex justify-between">
                        <span>⭐ Note Client Moyenne:</span>
                        <strong className="text-amber-400 font-mono">{selectedJob.provider.ratingAvg}/5 ({selectedJob.provider.reviewsCount} avis)</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>📊 Score de Confiance LinkedIn:</span>
                        <strong className="text-emerald-400 font-mono">{selectedJob.provider.trustScore}% Certifié</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>⚡ Réactivité Messagerie:</span>
                        <span className="text-slate-400 font-mono">~{selectedJob.provider.responseRate}% sous 1h</span>
                      </div>
                    </div>

                    {/* Sample reviews extracted snippet from that profile */}
                    <div className="text-[10px] text-slate-400 border-t border-slate-800 pt-2 space-y-1">
                      <span className="font-bold block text-slate-300">Dernier avis vérifié :</span>
                      <p className="italic bg-slate-950 p-1.5 rounded text-slate-400">
                        "Prestation haut de gamme, outillage professionnel. Je recommande vivement pour les chantiers sérieux sur Douala/Yaoundé."
                      </p>
                    </div>

                  </div>

                  {/* Immediate Action Row CTAs */}
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    
                    {/* Instant Secure Chat tab redirect */}
                    <button 
                      onClick={() => {
                        setActiveChatJobId(selectedJob.id);
                        setCurrentTab('chat');
                      }}
                      className="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-100 font-bold p-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5"
                    >
                      <MessageSquare className="w-4 h-4 text-amber-400" />
                      <span>{language === 'fr' ? 'Ouvrir Chat Sec' : 'Open Safe Chat'}</span>
                    </button>

                    {/* External WhatsApp action handler */}
                    <a 
                      href={`https://wa.me/${selectedJob.phone.replace(/[^0-9+]/g, '')}?text=Bonjour%20${encodeURIComponent(selectedJob.provider.name)},%20je%2520suis%20interesse%20par%20votre%20annonce%20JobMarket%20:%20${encodeURIComponent(selectedJob.title)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold p-2.5 rounded-xl text-xs flex items-center justify-center gap-1 text-center shadow-lg active:scale-95 transition-all"
                    >
                      <span>💬 WhatsApp Express</span>
                    </a>

                  </div>

                  {/* Report Advertisement Safety Tool */}
                  <div className="pt-2 flex justify-between items-center text-[11px] text-slate-400">
                    <span className="flex items-center gap-1 text-[10px]">
                      🛡️ Anti-Spam protection active
                    </span>
                    
                    <button 
                      onClick={() => {
                        const reason = prompt(language === 'fr' ? "Motif du signalement (Fraude, faux numéro, prix mensonger) :" : "Reason for reporting :");
                        if (reason) reportJob(selectedJob.id, reason);
                      }}
                      className="text-red-400 hover:text-red-300 hover:underline transition-colors"
                    >
                      🚨 Signaler une suspicion de fraude
                    </button>
                  </div>
                </>
              ) : (
                <div className="text-center py-12 text-slate-400 space-y-2">
                  <p>Aucun job sélectionné par défaut.</p>
                  <p className="text-xs">Choisissez un élément dans le flux de gauche ou sur la carte pour inspecter les métriques avancées.</p>
                </div>
              )}

            </div>

            {/* PREVIEW OF QUICK REVENUE AND SYSTEM CAPABILITY METRICS */}
            <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-900 p-4 rounded-2xl border border-slate-800 text-xs space-y-2 text-slate-300">
              <div className="flex justify-between items-center text-amber-400 font-bold">
                <span>📈 Statistiques Globales JobMarket PRO MAX</span>
                <span className="bg-slate-800 px-2 py-0.5 rounded text-[9px] font-mono">Live telemetry</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Plateforme configurée pour l'Afrique subsaharienne avec adaptation automatique du réseau de cache et compression d'images.
              </p>
              <div className="grid grid-cols-3 gap-2 pt-1 font-mono text-center text-[10px]">
                <div className="bg-slate-850 p-1.5 rounded">
                  <span className="block text-slate-400">PWA SW Cache</span>
                  <span className="text-emerald-400 font-bold">ACTIF 🟢</span>
                </div>
                <div className="bg-slate-850 p-1.5 rounded">
                  <span className="block text-slate-400">Coût Serveur</span>
                  <span className="text-slate-200 font-bold">0.00 XAF</span>
                </div>
                <div className="bg-slate-850 p-1.5 rounded">
                  <span className="block text-slate-400">Anti-Spam CDN</span>
                  <span className="text-blue-400 font-bold">Hardened</span>
                </div>
              </div>
            </div>

          </div>

        </div>
      </main>

      {/* FLOATING DRAWER OVERLAY DIALOG FOR INSTANT JOB POSTING (GLOVO / JUMIA LIGHTWEIGHT UX) */}
      {showPostDrawer && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-850 border border-slate-700 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl animate-scaleUp">
            
            {/* Header */}
            <div className="bg-slate-800 p-4 px-6 border-b border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-amber-400" />
                <h3 className="font-extrabold text-base text-slate-100">
                  {language === 'fr' ? 'Publier un Job avec Précision GPS' : 'Publish with Live GPS Precision'}
                </h3>
              </div>
              <button 
                onClick={() => setShowPostDrawer(false)}
                className="bg-slate-900 text-slate-400 hover:text-white px-3 py-1 rounded-xl text-xs font-bold"
              >
                ✕ Fermer
              </button>
            </div>

            {/* Form Content body */}
            <form onSubmit={handleCreateJob} className="p-6 space-y-4 max-h-[78vh] overflow-y-auto text-xs text-slate-300">
              
              {spamCooldown > 0 && (
                <div className="bg-red-950 border border-red-500/40 text-red-400 p-3 rounded-xl font-bold text-center">
                  ⚠️ Protection Anti-Spam activée. Attendez encore {spamCooldown} secondes avant de soumettre une nouvelle annonce.
                </div>
              )}

              {/* Title Input field */}
              <div className="space-y-1">
                <label className="block text-slate-300 font-bold">Titre explicite de la mission *</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ex: Électricien pour dépannage de climatiseur inverter ou Maçon coffreur..."
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Category selector slider dropdown */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-slate-300 font-bold">Métier / Catégorie</label>
                  <select 
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 focus:outline-none"
                  >
                    <option value="⚡ Électricité">⚡ Électricité & Froid</option>
                    <option value="🔧 BTP">🔧 BTP / Gros Œuvre / Coffrage</option>
                    <option value="💧 Plomberie">💧 Plomberie & Sanitaires</option>
                    <option value="🧹 Ménage">🧹 Ménage & Nettoyage</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-slate-300 font-bold">Ville principale</label>
                  <select 
                    value={formCity}
                    onChange={(e) => setFormCity(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 focus:outline-none"
                  >
                    <option value="Yaoundé">Yaoundé (Centre)</option>
                    <option value="Douala">Douala (Littoral)</option>
                    <option value="Kribi">Kribi (Sud)</option>
                    <option value="Bafoussam">Bafoussam (Ouest)</option>
                    <option value="Garoua">Garoua (Nord)</option>
                  </select>
                </div>
              </div>

              {/* Budget price amount and WhatsApp fields */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-slate-300 font-bold">Budget estimé ({currency}) *</label>
                  <input 
                    type="number" 
                    required
                    placeholder="Ex: 45000"
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 placeholder-slate-500 font-mono focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-slate-300 font-bold">Téléphone WhatsApp</label>
                  <input 
                    type="text" 
                    placeholder="+237 6..."
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 font-mono focus:outline-none"
                  />
                </div>
              </div>

              {/* Landmark accurate descriptor */}
              <div className="space-y-1">
                <label className="block text-slate-300 font-bold">Repère précis / Quartier (Axe Uber précis) *</label>
                <input 
                  type="text" 
                  placeholder="Ex: Bastos face Ambassade, Akwa rue de la joie, de l'école publique"
                  value={formLandmark}
                  required
                  onChange={(e) => setFormLandmark(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none"
                />
              </div>

              {/* Textarea description item detail */}
              <div className="space-y-1">
                <label className="block text-slate-300 font-bold">Description des exigences techniques & compétences requises</label>
                <textarea 
                  rows={3}
                  placeholder="Expliquez clairement le travail à faire. Évitez les mots suspects pour que l'intelligence artificielle de modération valide automatiquement l'offre sans délai."
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none"
                ></textarea>
              </div>

              {/* Multi image preview simulation widget */}
              <div className="space-y-2">
                <label className="block text-slate-300 font-bold">
                  🖼️ Multi-Images Galeries (Simulation de livraison CDN Cloudinary)
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {uploadedImagesPreview.map((img, idx) => (
                    <div key={idx} className="h-14 rounded-lg bg-slate-800 border border-slate-700 overflow-hidden relative">
                      <img src={img} alt="Preview" className="w-full h-full object-cover" />
                      <button 
                        type="button"
                        onClick={() => setUploadedImagesPreview(uploadedImagesPreview.filter((_, i) => i !== idx))}
                        className="absolute inset-0 bg-red-600/80 text-white font-bold flex items-center justify-center opacity-0 hover:opacity-100 text-[10px] transition-opacity"
                      >
                        Retirer
                      </button>
                    </div>
                  ))}
                  
                  {/* Button to simulate adding another image link */}
                  <button
                    type="button"
                    onClick={() => {
                      const sampleImages = [
                        "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=400&q=80",
                        "https://images.unsplash.com/photo-1581092921461-eab62e97a780?auto=format&fit=crop&w=400&q=80",
                        "https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?auto=format&fit=crop&w=400&q=80"
                      ];
                      const chosen = sampleImages[Math.floor(Math.random() * sampleImages.length)];
                      setUploadedImagesPreview([...uploadedImagesPreview, chosen]);
                    }}
                    className="h-14 rounded-lg border border-dashed border-slate-600 hover:border-amber-400 text-slate-400 hover:text-amber-400 font-mono text-[10px] flex flex-col items-center justify-center"
                  >
                    <span>➕ Photo</span>
                    <span>Simulate</span>
                  </button>
                </div>
                <p className="text-[10px] text-slate-400">
                  L'image est automatiquement compressée localement pour économiser la bande passante mobile 3G/4G au Cameroun.
                </p>
              </div>

              {/* Privacy agreement layer check box */}
              <div className="p-3 bg-slate-900 rounded-xl text-[10px] text-slate-400 space-y-1">
                <p className="font-bold text-slate-300">🛡️ Règles Firebase avancées & Protection Civile :</p>
                <p>
                  En publiant cette offre, vous certifiez posséder les fonds pour rémunérer le prestataire. Les tentatives d'escroqueries sont tracées par adresse IP simulée et transmises à la modération du Hub.
                </p>
              </div>

              {/* Submit trigger button */}
              <button
                type="submit"
                disabled={spamCooldown > 0}
                className={`w-full bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-black p-3 rounded-xl text-xs transition-transform transform active:scale-95 ${spamCooldown > 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                🚀 {language === 'fr' ? 'Diffuser instantanément sur toute l\'Afrique' : 'Broadcast to the Job Network Now'}
              </button>

            </form>

          </div>
        </div>
      )}

      {/* FOOTER METRICS AND QUICK BOTTOM CONTROLS MOBILE COMPACT STICKY BAR */}
      <footer className="bg-slate-950 text-slate-500 text-center py-8 px-4 text-xs border-t border-slate-800 space-y-3">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <p className="font-bold text-slate-300">JobMarket Cameroon PRO MAX — Ultimate Super Ecosystem</p>
            <p className="text-[11px] text-slate-500">Inspiré des meilleurs standards LinkedIn, Uber, WhatsApp, Glovo & Airbnb.</p>
          </div>

          <div className="flex flex-wrap gap-3 font-mono text-[11px]">
            <span className="bg-slate-900 px-2 py-1 rounded text-slate-300">📍 Live GPS Sorting: Active</span>
            <span className="bg-slate-900 px-2 py-1 rounded text-slate-300">💬 AES-256 Chats Encrypted</span>
            <span className="bg-slate-900 px-2 py-1 rounded text-slate-300">🛡️ Fraud AI Score: 2.1 Ready</span>
          </div>
        </div>
        <p className="text-[10px] text-slate-600 pt-2">
          © 2026 JobMarket Cameroon Future Inc. Déploiement international préparé pour l'expansion continentale. Tous droits réservés.
        </p>
      </footer>

    </div>
  );
}
