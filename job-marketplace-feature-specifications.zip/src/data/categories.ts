import type { Category } from '../types';

export const CATEGORIES: Category[] = [
  { key: 'all', label: 'Tous', icon: '🏠', color: '#111', bg: '#FFD700' },
  { key: 'btp', label: 'BTP', icon: '🔧', color: '#fff', bg: '#FF6B35' },
  { key: 'elec', label: 'Électricité', icon: '⚡', color: '#111', bg: '#FFD700' },
  { key: 'plomb', label: 'Plomberie', icon: '💧', color: '#fff', bg: '#007AFF' },
  { key: 'menage', label: 'Ménage', icon: '🧹', color: '#fff', bg: '#25D366' },
  { key: 'agri', label: 'Agriculture', icon: '🌿', color: '#fff', bg: '#34C759' },
  { key: 'sante', label: 'Santé', icon: '🏥', color: '#fff', bg: '#FF2D55' },
  { key: 'transport', label: 'Transport', icon: '🚗', color: '#fff', bg: '#FF9500' },
  { key: 'info', label: 'Informatique', icon: '💻', color: '#fff', bg: '#5856D6' },
  { key: 'edu', label: 'Éducation', icon: '📚', color: '#fff', bg: '#AF52DE' },
];

export const getCategoryByKey = (key: string): Category => {
  return CATEGORIES.find(c => c.key === key) || CATEGORIES[0];
};

export const getCategoryColor = (category: string): string => {
  const cat = CATEGORIES.find(c => c.key === category);
  return cat?.bg || '#FFD700';
};
