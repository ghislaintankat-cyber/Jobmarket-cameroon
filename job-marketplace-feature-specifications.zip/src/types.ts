export interface Job {
  id: string;
  title: string;
  price: string;
  phone: string;
  landmark: string;
  desc: string;
  icon: string;
  category: string;
  color: string;
  lat: number;
  lng: number;
  images: string[];
  userId: string;
  userName: string;
  verified: boolean;
  ratingAvg: number;
  ratingCount: number;
  timestamp: number;
  country: string;
  currency: string;
  status: 'open' | 'in_progress' | 'completed' | 'cancelled';
  trustScore: number;
  completedJobs: number;
  responseRate: number;
  badges: string[];
  dist?: number;
  saved?: boolean;
  language: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: number;
  read: boolean;
  jobId?: string;
}

export interface Chat {
  id: string;
  jobId: string;
  jobTitle: string;
  otherUserName: string;
  lastMessage: string;
  lastTimestamp: number;
  unread: number;
}

export interface Report {
  jobId: string;
  reporterId: string;
  reason: string;
  timestamp: number;
}

export type TabType = 'map' | 'list' | 'post' | 'search' | 'account';
export type CategoryKey = 'all' | 'btp' | 'elec' | 'plomb' | 'menage' | 'agri' | 'sante' | 'transport' | 'info' | 'edu';

export interface Category {
  key: CategoryKey;
  label: string;
  icon: string;
  color: string;
  bg: string;
}

export interface FilterOptions {
  category: CategoryKey;
  minPrice: number | null;
  maxPrice: number | null;
  verifiedOnly: boolean;
  maxDistance: number | null;
  sortBy: 'distance' | 'rating' | 'recent' | 'price';
}

export interface Notification {
  id: string;
  title: string;
  body: string;
  timestamp: number;
  read: boolean;
  type: 'new_job' | 'message' | 'rating' | 'system';
}
