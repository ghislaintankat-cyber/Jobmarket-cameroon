import { MapPin, Plus, Minus, Map } from 'lucide-react';
import type L from 'leaflet';

interface MapControlsProps {
  mapRef: React.MutableRefObject<L.Map | null>;
  onLocate: () => void;
  onToggleLayer: () => void;
  locating: boolean;
  nearestJobDist: number | null;
}

export default function MapControls({
  mapRef,
  onLocate,
  onToggleLayer,
  locating,
  nearestJobDist,
}: MapControlsProps) {
  const zoomIn = () => mapRef.current?.zoomIn();
  const zoomOut = () => mapRef.current?.zoomOut();

  return (
    <div
      className="fixed flex flex-col gap-3"
      style={{ right: 14, top: 150, zIndex: 50 }}
    >
      {/* Locate me */}
      <button
        onClick={onLocate}
        className="map-ctrl-btn"
        style={{ background: locating ? '#FFD700' : 'rgba(20,20,20,0.88)' }}
        title="Ma position"
      >
        <MapPin size={20} color={locating ? '#111' : 'white'} />
      </button>

      {/* Zoom in */}
      <button onClick={zoomIn} className="map-ctrl-btn" title="Zoom +">
        <Plus size={22} color="white" strokeWidth={2.5} />
      </button>

      {/* Zoom out */}
      <button onClick={zoomOut} className="map-ctrl-btn" title="Zoom -">
        <Minus size={22} color="white" strokeWidth={2.5} />
      </button>

      {/* Toggle map layer */}
      <button onClick={onToggleLayer} className="map-ctrl-btn" title="Changer fond de carte">
        <Map size={20} color="white" />
      </button>

      {/* Distance panel */}
      {nearestJobDist !== null && (
        <div
          style={{
            background: 'rgba(20,20,20,0.92)',
            backdropFilter: 'blur(10px)',
            borderRadius: 16,
            padding: '10px 12px',
            textAlign: 'center',
            boxShadow: '0 4px 16px rgba(0,0,0,0.4)',
          }}
        >
          <div
            style={{
              fontSize: 9,
              fontWeight: 700,
              color: '#aaa',
              letterSpacing: 1,
              textTransform: 'uppercase',
              marginBottom: 2,
            }}
          >
            DISTANCE
          </div>
          <div
            style={{
              fontSize: 22,
              fontWeight: 900,
              color: '#FFD700',
              lineHeight: 1,
            }}
          >
            {nearestJobDist.toFixed(1)}
          </div>
          <div style={{ fontSize: 10, fontWeight: 700, color: '#aaa' }}>KM</div>
        </div>
      )}
    </div>
  );
}
