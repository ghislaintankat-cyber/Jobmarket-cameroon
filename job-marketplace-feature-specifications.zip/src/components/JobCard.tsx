import { Heart, Star, MapPin, Shield, Phone, MessageCircle, Flag } from 'lucide-react';
import type { Job } from '../types';
import { getCategoryColor } from '../data/categories';

interface JobCardProps {
  job: Job;
  isSaved: boolean;
  onSave: () => void;
  onContact: () => void;
  onReport: () => void;
  onSelect: () => void;
  compact?: boolean;
}

function StarRating({ value, count }: { value: number; count: number }) {
  return (
    <div className="flex items-center gap-1">
      <div className="flex">
        {[1, 2, 3, 4, 5].map(i => (
          <Star
            key={i}
            size={11}
            fill={i <= Math.round(value) ? '#FFD700' : 'none'}
            color={i <= Math.round(value) ? '#FFD700' : '#ccc'}
          />
        ))}
      </div>
      <span style={{ fontSize: 11, fontWeight: 700, color: '#666' }}>
        {value.toFixed(1)} ({count})
      </span>
    </div>
  );
}

export default function JobCard({
  job,
  isSaved,
  onSave,
  onContact,
  onReport,
  onSelect,
  compact = false,
}: JobCardProps) {
  const catColor = getCategoryColor(job.category);
  const textColor = catColor === '#FFD700' ? '#111' : 'white';

  return (
    <div
      onClick={onSelect}
      style={{
        background: 'white',
        borderRadius: 20,
        padding: compact ? '14px' : '16px',
        marginBottom: 12,
        boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
        cursor: 'pointer',
        transition: 'all 0.2s',
        border: '1.5px solid rgba(0,0,0,0.04)',
      }}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          {/* Category badge */}
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: 14,
              background: catColor,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 22,
              flexShrink: 0,
            }}
          >
            {job.icon}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span
                style={{
                  fontWeight: 800,
                  fontSize: 15,
                  color: '#111',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}
              >
                {job.title}
              </span>
              {job.verified && (
                <div
                  style={{
                    background: 'linear-gradient(135deg, #007AFF, #5AC8FA)',
                    borderRadius: 20,
                    padding: '2px 7px',
                    fontSize: 9,
                    fontWeight: 800,
                    color: 'white',
                    flexShrink: 0,
                  }}
                >
                  ✓ VÉRIFIÉ
                </div>
              )}
            </div>
            <StarRating value={job.ratingAvg} count={job.ratingCount} />
          </div>
        </div>

        {/* Save button */}
        <button
          onClick={e => {
            e.stopPropagation();
            onSave();
          }}
          style={{ border: 'none', background: 'none', cursor: 'pointer', padding: 4 }}
        >
          <Heart
            size={20}
            fill={isSaved ? '#FF3B30' : 'none'}
            color={isSaved ? '#FF3B30' : '#ccc'}
          />
        </button>
      </div>

      {/* Location & distance */}
      <div className="flex items-center gap-1 mb-3">
        <MapPin size={13} color="#999" />
        <span style={{ fontSize: 12, color: '#888', fontWeight: 500 }}>{job.landmark}</span>
        {job.dist !== undefined && (
          <>
            <span style={{ color: '#ddd' }}>•</span>
            <span
              style={{
                fontSize: 12,
                fontWeight: 800,
                color: '#007AFF',
              }}
            >
              {job.dist} km
            </span>
          </>
        )}
      </div>

      {!compact && (
        <p
          style={{
            fontSize: 13,
            color: '#666',
            marginBottom: 12,
            lineHeight: 1.5,
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}
        >
          {job.desc}
        </p>
      )}

      {/* Badges */}
      {job.badges.length > 0 && (
        <div className="flex gap-2 mb-3 flex-wrap">
          {job.badges.map(badge => (
            <span
              key={badge}
              style={{
                background: '#F5F5F7',
                borderRadius: 8,
                padding: '3px 8px',
                fontSize: 10,
                fontWeight: 700,
                color: '#555',
              }}
            >
              {badge === 'verified' ? '✓ Vérifié' :
               badge === 'top_rated' ? '⭐ Top Rated' :
               badge === 'elite' ? '👑 Élite' :
               badge === 'new_talent' ? '🚀 New Talent' : badge}
            </span>
          ))}
        </div>
      )}

      {/* Provider stats */}
      {!compact && (
        <div
          className="flex gap-3 mb-3"
          style={{
            background: '#F5F5F7',
            borderRadius: 12,
            padding: '10px 12px',
          }}
        >
          <div className="flex-1 text-center">
            <div style={{ fontSize: 15, fontWeight: 800, color: '#111' }}>{job.completedJobs}</div>
            <div style={{ fontSize: 10, color: '#888', fontWeight: 600 }}>Jobs</div>
          </div>
          <div style={{ width: 1, background: '#ddd' }} />
          <div className="flex-1 text-center">
            <div style={{ fontSize: 15, fontWeight: 800, color: '#111' }}>{job.responseRate}%</div>
            <div style={{ fontSize: 10, color: '#888', fontWeight: 600 }}>Réponse</div>
          </div>
          <div style={{ width: 1, background: '#ddd' }} />
          <div className="flex-1 text-center">
            <div style={{ fontSize: 15, fontWeight: 800, color: '#FFD700' }}>
              <Shield size={14} style={{ display: 'inline' }} /> {job.trustScore}
            </div>
            <div style={{ fontSize: 10, color: '#888', fontWeight: 600 }}>Trust</div>
          </div>
        </div>
      )}

      {/* Price & Actions */}
      <div className="flex items-center justify-between">
        <div>
          <div style={{ fontSize: 18, fontWeight: 900, color: '#111' }}>{job.price}</div>
          <div style={{ fontSize: 11, color: '#aaa', fontWeight: 500 }}>Budget estimé</div>
        </div>

        <div className="flex gap-2">
          <button
            onClick={e => {
              e.stopPropagation();
              onReport();
            }}
            style={{
              width: 38,
              height: 38,
              borderRadius: 12,
              background: '#F5F5F7',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
            }}
          >
            <Flag size={16} color="#FF3B30" />
          </button>

          <button
            onClick={e => {
              e.stopPropagation();
              window.open(
                `https://wa.me/${job.phone.replace(/\D/g, '')}?text=Bonjour, je vous contacte pour: ${encodeURIComponent(job.title)}`,
                '_blank'
              );
            }}
            style={{
              height: 38,
              borderRadius: 12,
              background: '#25D366',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 6,
              padding: '0 14px',
              cursor: 'pointer',
              color: 'white',
              fontWeight: 800,
              fontSize: 13,
            }}
          >
            <MessageCircle size={15} />
            WhatsApp
          </button>

          <button
            onClick={e => {
              e.stopPropagation();
              onContact();
            }}
            style={{
              width: 38,
              height: 38,
              borderRadius: 12,
              background: '#007AFF',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
            }}
          >
            <Phone size={15} color="white" />
          </button>
        </div>
      </div>
    </div>
  );
}
