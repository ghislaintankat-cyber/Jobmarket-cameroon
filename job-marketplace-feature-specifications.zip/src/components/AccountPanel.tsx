import { useState } from 'react';
import {
  User, Star, Shield, CheckCircle, Settings, LogOut,
  Heart, MessageSquare, Bell, ChevronRight, Award
} from 'lucide-react';
import type { Job, Notification } from '../types';
import JobCard from './JobCard';

interface AccountPanelProps {
  savedJobs: Job[];
  savedJobIds?: Set<string>;
  onSave: (id: string) => void;
  onSelectJob: (job: Job) => void;
  notifications: Notification[];
  onMarkAllRead: () => void;
}

export default function AccountPanel({
  savedJobs,
  savedJobIds,
  onSave,
  onSelectJob,
  notifications,
  onMarkAllRead,
}: AccountPanelProps) {
  const [tab, setTab] = useState<'profile' | 'saved' | 'notifications' | 'settings'>('profile');
  const unreadCount = notifications.filter(n => !n.read).length;

  const TABS = [
    { key: 'profile', icon: User, label: 'Profil' },
    { key: 'saved', icon: Heart, label: 'Favoris' },
    { key: 'notifications', icon: Bell, label: `Alertes${unreadCount > 0 ? ` (${unreadCount})` : ''}` },
    { key: 'settings', icon: Settings, label: 'Paramètres' },
  ] as const;

  return (
    <div
      className="fixed inset-0 flex flex-col"
      style={{ background: '#F5F5F7', zIndex: 200, paddingTop: 60, paddingBottom: 80 }}
    >
      {/* Sub-tabs */}
      <div
        className="flex overflow-x-auto gap-1 px-3 py-3"
        style={{ background: 'white', boxShadow: '0 2px 10px rgba(0,0,0,0.06)', scrollbarWidth: 'none' }}
      >
        {TABS.map(t => {
          const Icon = t.icon;
          const isActive = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              style={{
                background: isActive ? '#FFD700' : '#F5F5F7',
                border: 'none',
                borderRadius: 20,
                padding: '8px 14px',
                fontSize: 12,
                fontWeight: 700,
                color: '#111',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 5,
                flexShrink: 0,
                boxShadow: isActive ? '0 3px 12px rgba(255,215,0,0.4)' : 'none',
              }}
            >
              <Icon size={13} />
              {t.label}
            </button>
          );
        })}
      </div>

      <div className="flex-1 overflow-y-auto px-4 pt-4">
        {/* PROFILE */}
        {tab === 'profile' && (
          <div>
            {/* Avatar + Trust */}
            <div
              style={{
                background: 'white',
                borderRadius: 20,
                padding: 20,
                marginBottom: 12,
                textAlign: 'center',
              }}
            >
              <div
                style={{
                  width: 80,
                  height: 80,
                  borderRadius: '50%',
                  background: 'linear-gradient(135deg, #FFD700, #FF9500)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 12px',
                  fontSize: 30,
                  fontWeight: 900,
                  color: '#111',
                  boxShadow: '0 8px 24px rgba(255,215,0,0.4)',
                }}
              >
                JM
              </div>
              <div style={{ fontWeight: 800, fontSize: 18, color: '#111', marginBottom: 4 }}>
                Mon Profil
              </div>
              <div style={{ fontSize: 13, color: '#888', marginBottom: 14 }}>
                Yaoundé, Cameroun
              </div>

              {/* Trust ring */}
              <div className="flex items-center justify-center gap-6">
                <div className="text-center">
                  <div style={{ fontSize: 22, fontWeight: 900, color: '#FFD700' }}>95</div>
                  <div style={{ fontSize: 11, color: '#888', fontWeight: 600 }}>Trust Score</div>
                </div>
                <div className="text-center">
                  <div style={{ fontSize: 22, fontWeight: 900, color: '#111' }}>4.8</div>
                  <div style={{ fontSize: 11, color: '#888', fontWeight: 600 }}>Note moy.</div>
                </div>
                <div className="text-center">
                  <div style={{ fontSize: 22, fontWeight: 900, color: '#007AFF' }}>23</div>
                  <div style={{ fontSize: 11, color: '#888', fontWeight: 600 }}>Jobs fait</div>
                </div>
              </div>
            </div>

            {/* Badges */}
            <div style={{ background: 'white', borderRadius: 20, padding: 16, marginBottom: 12 }}>
              <div style={{ fontWeight: 800, fontSize: 15, color: '#111', marginBottom: 12 }}>
                🏆 Mes badges
              </div>
              <div className="flex gap-3 flex-wrap">
                {[
                  { icon: '✓', label: 'Vérifié', color: '#007AFF' },
                  { icon: '⭐', label: 'Top Rated', color: '#FFD700' },
                  { icon: '🛡️', label: 'Sécurisé', color: '#25D366' },
                ].map(badge => (
                  <div
                    key={badge.label}
                    style={{
                      background: '#F5F5F7',
                      borderRadius: 12,
                      padding: '10px 14px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: 6,
                    }}
                  >
                    <span style={{ fontSize: 18 }}>{badge.icon}</span>
                    <span style={{ fontSize: 12, fontWeight: 700, color: '#333' }}>{badge.label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div style={{ background: 'white', borderRadius: 20, padding: 16, marginBottom: 12 }}>
              <div style={{ fontWeight: 800, fontSize: 15, color: '#111', marginBottom: 12 }}>
                📊 Statistiques
              </div>
              {[
                { label: 'Taux de réponse', value: '98%', icon: <MessageSquare size={16} color="#007AFF" /> },
                { label: 'Jobs complétés', value: '23', icon: <CheckCircle size={16} color="#25D366" /> },
                { label: 'Avis positifs', value: '21/23', icon: <Star size={16} color="#FFD700" /> },
                { label: 'Score de confiance', value: '95/100', icon: <Shield size={16} color="#FF9500" /> },
                { label: 'Niveau', value: 'Expert', icon: <Award size={16} color="#AF52DE" /> },
              ].map(stat => (
                <div
                  key={stat.label}
                  className="flex items-center justify-between py-3"
                  style={{ borderBottom: '1px solid #F5F5F7' }}
                >
                  <div className="flex items-center gap-3">
                    {stat.icon}
                    <span style={{ fontSize: 13, fontWeight: 600, color: '#333' }}>{stat.label}</span>
                  </div>
                  <span style={{ fontSize: 13, fontWeight: 800, color: '#111' }}>{stat.value}</span>
                </div>
              ))}
            </div>

            {/* Quick actions */}
            <div style={{ background: 'white', borderRadius: 20, padding: 16, marginBottom: 12 }}>
              {[
                { icon: '💬', label: 'Chat sécurisé', sub: '2 conversations actives' },
                { icon: '📋', label: 'Mes annonces', sub: '3 jobs actifs' },
                { icon: '⚙️', label: 'Paramètres compte', sub: 'Vérification, sécurité' },
              ].map(item => (
                <button
                  key={item.label}
                  className="flex items-center w-full py-3 gap-3"
                  style={{
                    background: 'none',
                    border: 'none',
                    borderBottom: '1px solid #F5F5F7',
                    cursor: 'pointer',
                    textAlign: 'left',
                  }}
                >
                  <span style={{ fontSize: 22, width: 40 }}>{item.icon}</span>
                  <div className="flex-1">
                    <div style={{ fontWeight: 700, fontSize: 14, color: '#111' }}>{item.label}</div>
                    <div style={{ fontSize: 12, color: '#888' }}>{item.sub}</div>
                  </div>
                  <ChevronRight size={16} color="#ccc" />
                </button>
              ))}
            </div>

            {/* Logout */}
            <button
              style={{
                width: '100%',
                padding: '14px',
                borderRadius: 16,
                background: '#FF3B30',
                border: 'none',
                color: 'white',
                fontWeight: 800,
                fontSize: 15,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
                marginBottom: 20,
              }}
            >
              <LogOut size={18} />
              Déconnexion
            </button>
          </div>
        )}

        {/* SAVED JOBS */}
        {tab === 'saved' && (
          <div>
            {savedJobs.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64">
                <Heart size={48} color="#ddd" />
                <div style={{ fontWeight: 700, fontSize: 16, color: '#333', marginTop: 12 }}>Aucun favori</div>
                <div style={{ fontSize: 13, color: '#888', marginTop: 4 }}>
                  Sauvegardez des jobs pour les retrouver ici
                </div>
              </div>
            ) : (
              savedJobs.map(job => (
                <JobCard
                  key={job.id}
                  job={job}
                  isSaved={true}
                  onSave={() => onSave(job.id)}
                  onReport={() => {}}
                  onContact={() => window.open(`tel:${job.phone}`)}
                  onSelect={() => onSelectJob(job)}
                  compact
                />
              ))
            )}
          </div>
        )}

        {/* NOTIFICATIONS */}
        {tab === 'notifications' && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <div style={{ fontWeight: 800, fontSize: 16, color: '#111' }}>Notifications</div>
              {unreadCount > 0 && (
                <button
                  onClick={onMarkAllRead}
                  style={{
                    background: 'none',
                    border: 'none',
                    fontSize: 12,
                    fontWeight: 700,
                    color: '#007AFF',
                    cursor: 'pointer',
                  }}
                >
                  Tout marquer lu
                </button>
              )}
            </div>
            {notifications.map(notif => (
              <div
                key={notif.id}
                style={{
                  background: notif.read ? 'white' : '#FFFBE6',
                  borderRadius: 16,
                  padding: '14px',
                  marginBottom: 8,
                  border: notif.read ? '1px solid #F0F0F0' : '1px solid #FFD70033',
                }}
              >
                <div className="flex items-start gap-3">
                  <div style={{ fontSize: 22 }}>
                    {notif.type === 'new_job' ? '📍' : notif.type === 'message' ? '💬' : notif.type === 'rating' ? '⭐' : '🔔'}
                  </div>
                  <div className="flex-1">
                    <div style={{ fontWeight: 700, fontSize: 13, color: '#111', marginBottom: 2 }}>
                      {notif.title}
                    </div>
                    <div style={{ fontSize: 12, color: '#666' }}>{notif.body}</div>
                    <div style={{ fontSize: 11, color: '#aaa', marginTop: 4 }}>
                      {Math.round((Date.now() - notif.timestamp) / 60000)} min
                    </div>
                  </div>
                  {!notif.read && (
                    <div
                      style={{
                        width: 8,
                        height: 8,
                        borderRadius: '50%',
                        background: '#FFD700',
                        marginTop: 3,
                        flexShrink: 0,
                      }}
                    />
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* SETTINGS */}
        {tab === 'settings' && (
          <div>
            <div style={{ background: 'white', borderRadius: 20, padding: 16, marginBottom: 12 }}>
              <div style={{ fontWeight: 800, fontSize: 15, color: '#111', marginBottom: 12 }}>
                🔒 Sécurité & Vérification
              </div>
              {[
                { label: 'Email vérifié', status: true, icon: '✉️' },
                { label: 'Téléphone vérifié', status: false, icon: '📱' },
                { label: 'Identité vérifiée', status: false, icon: '🪪' },
                { label: 'Double authentification', status: false, icon: '🔑' },
              ].map(item => (
                <div
                  key={item.label}
                  className="flex items-center justify-between py-3"
                  style={{ borderBottom: '1px solid #F5F5F7' }}
                >
                  <div className="flex items-center gap-3">
                    <span>{item.icon}</span>
                    <span style={{ fontSize: 13, fontWeight: 600, color: '#333' }}>{item.label}</span>
                  </div>
                  <span
                    style={{
                      fontSize: 11,
                      fontWeight: 800,
                      color: item.status ? '#25D366' : '#FF9500',
                      background: item.status ? '#E8F8F0' : '#FFF5E6',
                      padding: '4px 10px',
                      borderRadius: 20,
                    }}
                  >
                    {item.status ? '✓ Vérifié' : 'À vérifier'}
                  </span>
                </div>
              ))}
            </div>

            <div style={{ background: 'white', borderRadius: 20, padding: 16, marginBottom: 12 }}>
              <div style={{ fontWeight: 800, fontSize: 15, color: '#111', marginBottom: 12 }}>
                🌍 Préférences
              </div>
              {[
                { label: 'Pays', value: '🇨🇲 Cameroun' },
                { label: 'Devise', value: 'XAF (FCFA)' },
                { label: 'Langue', value: 'Français' },
                { label: 'Notifications push', value: 'Activées' },
              ].map(item => (
                <div
                  key={item.label}
                  className="flex items-center justify-between py-3"
                  style={{ borderBottom: '1px solid #F5F5F7' }}
                >
                  <span style={{ fontSize: 13, fontWeight: 600, color: '#333' }}>{item.label}</span>
                  <div className="flex items-center gap-2">
                    <span style={{ fontSize: 13, fontWeight: 700, color: '#666' }}>{item.value}</span>
                    <ChevronRight size={14} color="#ccc" />
                  </div>
                </div>
              ))}
            </div>

            <div style={{ background: 'white', borderRadius: 20, padding: 16, marginBottom: 20 }}>
              <div style={{ fontWeight: 800, fontSize: 15, color: '#111', marginBottom: 12 }}>
                ℹ️ Application
              </div>
              <div style={{ fontSize: 12, color: '#888', lineHeight: 1.6 }}>
                JobMarket Cameroon PRO MAX v2.0<br />
                Architecture Firebase + Cloudinary<br />
                PWA — Android prêt<br />
                © 2025 JobMarket Cameroon
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
