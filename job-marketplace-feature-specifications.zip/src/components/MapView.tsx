import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { Job } from '../types';
import type { Coords } from '../hooks/useGeolocation';
import { getCategoryColor } from '../data/categories';

interface MapViewProps {
  jobs: Job[];
  userCoords: Coords | null;
  selectedJob: Job | null;
  onJobSelect: (job: Job) => void;
  onMapClick: () => void;
  mapRef: React.MutableRefObject<L.Map | null>;
}

function createJobIcon(job: Job) {
  const color = getCategoryColor(job.category);
  const textColor = ['#FFD700'].includes(color) ? '#111' : 'white';
  const shortLabel = job.title.length > 8 ? job.title.substring(0, 7) + '…' : job.title;
  const html = `
    <div style="
      background: ${color};
      color: ${textColor};
      border: 2.5px solid white;
      border-radius: 10px;
      padding: 4px 9px;
      font-size: 11px;
      font-weight: 800;
      font-family: 'Plus Jakarta Sans', sans-serif;
      box-shadow: 0 3px 12px rgba(0,0,0,0.35);
      white-space: nowrap;
      pointer-events: none;
    ">${shortLabel}</div>
  `;
  return L.divIcon({
    html,
    className: '',
    iconAnchor: [40, 18],
    iconSize: [80, 36],
  });
}

function createUserIcon() {
  const html = `
    <div style="position:relative;width:24px;height:24px;">
      <div style="
        position:absolute;inset:-6px;
        border-radius:50%;
        background:rgba(0,122,255,0.2);
        animation: pulse-ring 2s cubic-bezier(0.215,0.61,0.355,1) infinite;
      "></div>
      <div style="
        width:20px;height:20px;
        background:#007AFF;
        border:3.5px solid white;
        border-radius:50%;
        box-shadow:0 2px 8px rgba(0,122,255,0.5);
        position:absolute;top:2px;left:2px;
      "></div>
    </div>
  `;
  return L.divIcon({
    html,
    className: '',
    iconAnchor: [12, 12],
    iconSize: [24, 24],
  });
}

export default function MapView({
  jobs,
  userCoords,
  selectedJob,
  onJobSelect,
  onMapClick,
  mapRef,
}: MapViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const markersRef = useRef<Map<string, L.Marker>>(new Map());
  const userMarkerRef = useRef<L.Marker | null>(null);
  const initializedRef = useRef(false);

  // Initialize map
  useEffect(() => {
    if (!containerRef.current || initializedRef.current) return;
    initializedRef.current = true;

    const map = L.map(containerRef.current, {
      center: [3.848, 11.502],
      zoom: 13,
      zoomControl: false,
      attributionControl: false,
    });

    // Satellite hybrid tiles (Google-like)
    L.tileLayer('https://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}', {
      subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
      maxZoom: 20,
    }).addTo(map);

    // Attribution small
    L.control.attribution({ position: 'bottomleft', prefix: '' }).addTo(map);

    map.on('click', () => onMapClick());
    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
      initializedRef.current = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Update job markers
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    // Remove old markers not in current jobs
    const currentIds = new Set(jobs.map(j => j.id));
    markersRef.current.forEach((marker, id) => {
      if (!currentIds.has(id)) {
        marker.remove();
        markersRef.current.delete(id);
      }
    });

    // Add/update markers
    jobs.forEach(job => {
      if (markersRef.current.has(job.id)) return;

      const marker = L.marker([job.lat, job.lng], { icon: createJobIcon(job) });

      const popupContent = `
        <div style="padding:14px;min-width:200px;font-family:'Plus Jakarta Sans',sans-serif;">
          <div style="font-size:13px;font-weight:800;margin-bottom:4px;">${job.title}</div>
          <div style="font-size:12px;color:#666;margin-bottom:6px;">${job.landmark}</div>
          <div style="font-size:14px;font-weight:800;color:#FFD700;margin-bottom:8px;">${job.price}</div>
          ${job.verified ? '<span style="background:#007AFF;color:white;font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;">✓ Vérifié</span>' : ''}
          <div style="margin-top:10px;display:flex;gap:8px;">
            <a href="https://wa.me/${job.phone.replace(/\D/g,'')}?text=Bonjour, je vous contacte pour: ${encodeURIComponent(job.title)}" target="_blank"
              style="flex:1;background:#25D366;color:white;text-align:center;padding:8px;border-radius:10px;font-size:12px;font-weight:700;text-decoration:none;">
              WhatsApp
            </a>
            <a href="tel:${job.phone}"
              style="flex:1;background:#007AFF;color:white;text-align:center;padding:8px;border-radius:10px;font-size:12px;font-weight:700;text-decoration:none;">
              Appeler
            </a>
          </div>
        </div>
      `;

      marker.bindPopup(popupContent, { maxWidth: 280 });
      marker.on('click', () => onJobSelect(job));
      marker.addTo(map);
      markersRef.current.set(job.id, marker);
    });
  }, [jobs, onJobSelect, mapRef]);

  // Update selected job marker
  useEffect(() => {
    if (!selectedJob || !mapRef.current) return;
    const marker = markersRef.current.get(selectedJob.id);
    if (marker) {
      mapRef.current.flyTo([selectedJob.lat, selectedJob.lng], 16, { duration: 0.8 });
      marker.openPopup();
    }
  }, [selectedJob, mapRef]);

  // Update user marker
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !userCoords) return;

    if (userMarkerRef.current) {
      userMarkerRef.current.setLatLng([userCoords.lat, userCoords.lng]);
    } else {
      userMarkerRef.current = L.marker([userCoords.lat, userCoords.lng], {
        icon: createUserIcon(),
        zIndexOffset: 1000,
      }).addTo(map);
    }
    map.flyTo([userCoords.lat, userCoords.lng], 15, { duration: 1.2 });
  }, [userCoords, mapRef]);

  return (
    <div
      ref={containerRef}
      style={{ position: 'absolute', inset: 0, zIndex: 0 }}
    />
  );
}
