import { Map, List, Plus, Search, User } from 'lucide-react';
import type { TabType } from '../types';

interface BottomNavProps {
  active: TabType;
  onChange: (tab: TabType) => void;
}

const NAV_ITEMS = [
  { tab: 'map' as TabType, icon: Map, label: 'Carte' },
  { tab: 'list' as TabType, icon: List, label: 'Liste' },
  { tab: 'post' as TabType, icon: Plus, label: '', isCenter: true },
  { tab: 'search' as TabType, icon: Search, label: 'Chercher' },
  { tab: 'account' as TabType, icon: User, label: 'Compte' },
];

export default function BottomNav({ active, onChange }: BottomNavProps) {
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 safe-bottom"
      style={{
        height: 80,
        background: 'rgba(255,255,255,0.97)',
        backdropFilter: 'blur(16px)',
        boxShadow: '0 -4px 24px rgba(0,0,0,0.12)',
        zIndex: 100,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-around',
        paddingBottom: 'env(safe-area-inset-bottom, 0px)',
      }}
    >
      {NAV_ITEMS.map(item => {
        const Icon = item.icon;
        const isActive = active === item.tab && item.tab !== 'post';

        if (item.isCenter) {
          return (
            <button
              key={item.tab}
              onClick={() => onChange(item.tab)}
              style={{
                width: 64,
                height: 64,
                borderRadius: '50%',
                background: '#FFD700',
                border: 'none',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                transform: 'translateY(-16px)',
                boxShadow: '0 6px 20px rgba(255,215,0,0.6)',
                flexShrink: 0,
              }}
            >
              <Icon size={28} color="#111" strokeWidth={2.5} />
            </button>
          );
        }

        return (
          <button
            key={item.tab}
            onClick={() => onChange(item.tab)}
            style={{
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 3,
              border: 'none',
              background: 'none',
              cursor: 'pointer',
              color: isActive ? '#FFD700' : '#999',
              paddingBottom: 4,
            }}
          >
            <Icon
              size={22}
              strokeWidth={isActive ? 2.5 : 1.8}
              color={isActive ? '#FFD700' : '#999'}
            />
            <span
              style={{
                fontSize: 11,
                fontWeight: isActive ? 800 : 600,
                lineHeight: 1,
              }}
            >
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
