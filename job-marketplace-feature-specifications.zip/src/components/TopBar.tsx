import { Bell, Plus } from 'lucide-react';

interface TopBarProps {
  notifCount: number;
  onNotifClick: () => void;
  onPublishClick: () => void;
}

export default function TopBar({ notifCount, onNotifClick, onPublishClick }: TopBarProps) {
  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4"
      style={{
        height: 60,
        background: 'rgba(255,255,255,0.97)',
        backdropFilter: 'blur(12px)',
        boxShadow: '0 2px 16px rgba(0,0,0,0.12)',
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-2">
        <div
          style={{
            width: 38,
            height: 38,
            background: '#FFD700',
            borderRadius: 10,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontWeight: 900,
            fontSize: 13,
            color: '#111',
            letterSpacing: -0.5,
          }}
        >
          JM
        </div>
        <div>
          <div style={{ fontWeight: 800, fontSize: 15, color: '#111', lineHeight: 1.1 }}>
            <span style={{ color: '#FFD700' }}>Job</span>Market
          </div>
          <div style={{ fontSize: 10, color: '#888', fontWeight: 600, letterSpacing: 0.5 }}>
            CAMEROON PRO
          </div>
        </div>
      </div>

      {/* Right actions */}
      <div className="flex items-center gap-2">
        {/* Notification bell */}
        <button
          onClick={onNotifClick}
          style={{
            position: 'relative',
            width: 40,
            height: 40,
            background: '#111',
            borderRadius: 12,
            border: 'none',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
          }}
        >
          <Bell size={18} color="white" />
          {notifCount > 0 && (
            <div
              style={{
                position: 'absolute',
                top: 6,
                right: 6,
                width: 8,
                height: 8,
                background: '#FF3B30',
                borderRadius: '50%',
                border: '1.5px solid white',
              }}
              className="notif-blink"
            />
          )}
        </button>

        {/* Publish button */}
        <button
          onClick={onPublishClick}
          style={{
            background: '#FFD700',
            border: 'none',
            borderRadius: 22,
            padding: '10px 16px',
            fontWeight: 800,
            fontSize: 14,
            color: '#111',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 5,
          }}
        >
          <Plus size={15} strokeWidth={3} />
          Publier
        </button>
      </div>
    </header>
  );
}
