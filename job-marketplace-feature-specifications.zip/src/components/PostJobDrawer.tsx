import { useState, useRef } from 'react';
import { X, Camera, MapPin, Phone, DollarSign, FileText, Tag } from 'lucide-react';
import type { Job } from '../types';
import type { CategoryKey } from '../types';
import { CATEGORIES } from '../data/categories';
import type { Coords } from '../hooks/useGeolocation';

interface PostJobDrawerProps {
  onClose: () => void;
  onSubmit: (job: Omit<Job, 'id' | 'timestamp' | 'dist'>) => void;
  userCoords: Coords | null;
  userId: string;
}

export default function PostJobDrawer({ onClose, onSubmit, userCoords, userId }: PostJobDrawerProps) {
  const [category, setCategory] = useState<CategoryKey>('elec');
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [phone, setPhone] = useState('');
  const [landmark, setLandmark] = useState('');
  const [desc, setDesc] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const selectedCat = CATEGORIES.find(c => c.key === category) || CATEGORIES[1];

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const previews: string[] = [];
    for (const file of Array.from(files)) {
      const reader = new FileReader();
      await new Promise<void>(resolve => {
        reader.onload = () => {
          previews.push(reader.result as string);
          resolve();
        };
        reader.readAsDataURL(file);
      });
    }
    setImages(prev => [...prev, ...previews].slice(0, 5));
  };

  const handleSubmit = async () => {
    if (!title.trim() || !price.trim() || !phone.trim()) {
      alert('Veuillez remplir les champs obligatoires (titre, prix, téléphone)');
      return;
    }
    setLoading(true);

    const cat = CATEGORIES.find(c => c.key === category)!;
    const jobData: Omit<Job, 'id' | 'timestamp' | 'dist'> = {
      title: title.trim(),
      price: `${price.trim()} XAF`,
      phone: phone.trim(),
      landmark: landmark.trim() || 'Yaoundé',
      desc: desc.trim(),
      icon: cat.icon,
      category: cat.key,
      color: cat.bg,
      lat: userCoords?.lat ?? 3.848 + (Math.random() - 0.5) * 0.03,
      lng: userCoords?.lng ?? 11.502 + (Math.random() - 0.5) * 0.03,
      images,
      userId: userId || 'anonymous',
      userName: 'Vous',
      verified: false,
      ratingAvg: 5.0,
      ratingCount: 0,
      country: 'Cameroon',
      currency: 'XAF',
      status: 'open',
      trustScore: 70,
      completedJobs: 0,
      responseRate: 100,
      badges: [],
      language: 'fr',
    };

    await new Promise(resolve => setTimeout(resolve, 800));
    onSubmit(jobData);
    setLoading(false);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 flex flex-col"
      style={{ zIndex: 300, background: 'rgba(0,0,0,0.5)' }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <div
        className="absolute bottom-0 left-0 right-0 flex flex-col"
        style={{
          background: 'white',
          borderRadius: '24px 24px 0 0',
          maxHeight: '90vh',
          paddingBottom: 'env(safe-area-inset-bottom, 0px)',
        }}
      >
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div style={{ width: 40, height: 4, background: '#ddd', borderRadius: 2 }} />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3">
          <div style={{ fontWeight: 800, fontSize: 20, color: '#111' }}>Publier un Job</div>
          <button
            onClick={onClose}
            style={{
              width: 36,
              height: 36,
              borderRadius: 12,
              background: '#F5F5F7',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
            }}
          >
            <X size={18} color="#666" />
          </button>
        </div>

        {/* Form */}
        <div className="flex-1 overflow-y-auto px-5 pb-6">
          {/* Category selector */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#888', marginBottom: 8 }}>CATÉGORIE</div>
            <div className="flex gap-2 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none' }}>
              {CATEGORIES.filter(c => c.key !== 'all').map(cat => (
                <button
                  key={cat.key}
                  onClick={() => setCategory(cat.key)}
                  style={{
                    background: category === cat.key ? cat.bg : '#F5F5F7',
                    color: category === cat.key ? cat.color : '#333',
                    border: 'none',
                    borderRadius: 16,
                    padding: '8px 12px',
                    fontSize: 12,
                    fontWeight: 700,
                    whiteSpace: 'nowrap',
                    cursor: 'pointer',
                    flexShrink: 0,
                    boxShadow: category === cat.key ? `0 4px 12px ${cat.bg}55` : 'none',
                  }}
                >
                  {cat.icon} {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div style={{ marginBottom: 14 }}>
            <div className="flex items-center gap-2 mb-2">
              <Tag size={14} color="#888" />
              <span style={{ fontSize: 12, fontWeight: 700, color: '#888' }}>TITRE DU JOB *</span>
            </div>
            <input
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Ex: Réparation électrique urgente"
              style={{
                width: '100%',
                padding: '14px',
                borderRadius: 14,
                border: '1.5px solid #eee',
                fontSize: 14,
                fontWeight: 600,
                fontFamily: 'inherit',
                outline: 'none',
              }}
            />
          </div>

          {/* Price */}
          <div style={{ marginBottom: 14 }}>
            <div className="flex items-center gap-2 mb-2">
              <DollarSign size={14} color="#888" />
              <span style={{ fontSize: 12, fontWeight: 700, color: '#888' }}>PRIX / BUDGET XAF *</span>
            </div>
            <input
              value={price}
              onChange={e => setPrice(e.target.value)}
              placeholder="Ex: 15000"
              type="number"
              style={{
                width: '100%',
                padding: '14px',
                borderRadius: 14,
                border: '1.5px solid #eee',
                fontSize: 14,
                fontWeight: 600,
                fontFamily: 'inherit',
                outline: 'none',
              }}
            />
          </div>

          {/* Phone */}
          <div style={{ marginBottom: 14 }}>
            <div className="flex items-center gap-2 mb-2">
              <Phone size={14} color="#888" />
              <span style={{ fontSize: 12, fontWeight: 700, color: '#888' }}>TÉLÉPHONE WHATSAPP *</span>
            </div>
            <input
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder="+237 6XX XXX XXX"
              type="tel"
              style={{
                width: '100%',
                padding: '14px',
                borderRadius: 14,
                border: '1.5px solid #eee',
                fontSize: 14,
                fontWeight: 600,
                fontFamily: 'inherit',
                outline: 'none',
              }}
            />
          </div>

          {/* Landmark */}
          <div style={{ marginBottom: 14 }}>
            <div className="flex items-center gap-2 mb-2">
              <MapPin size={14} color="#888" />
              <span style={{ fontSize: 12, fontWeight: 700, color: '#888' }}>QUARTIER / REPÈRE</span>
            </div>
            <input
              value={landmark}
              onChange={e => setLandmark(e.target.value)}
              placeholder="Ex: Bastos, Yaoundé"
              style={{
                width: '100%',
                padding: '14px',
                borderRadius: 14,
                border: '1.5px solid #eee',
                fontSize: 14,
                fontWeight: 600,
                fontFamily: 'inherit',
                outline: 'none',
              }}
            />
          </div>

          {/* Description */}
          <div style={{ marginBottom: 14 }}>
            <div className="flex items-center gap-2 mb-2">
              <FileText size={14} color="#888" />
              <span style={{ fontSize: 12, fontWeight: 700, color: '#888' }}>DESCRIPTION</span>
            </div>
            <textarea
              value={desc}
              onChange={e => setDesc(e.target.value)}
              placeholder="Décrivez le travail, vos compétences, disponibilités..."
              rows={3}
              style={{
                width: '100%',
                padding: '14px',
                borderRadius: 14,
                border: '1.5px solid #eee',
                fontSize: 14,
                fontWeight: 500,
                fontFamily: 'inherit',
                outline: 'none',
                resize: 'none',
              }}
            />
          </div>

          {/* Images */}
          <div style={{ marginBottom: 20 }}>
            <div className="flex items-center gap-2 mb-2">
              <Camera size={14} color="#888" />
              <span style={{ fontSize: 12, fontWeight: 700, color: '#888' }}>PHOTOS (max 5)</span>
            </div>
            <div className="flex gap-2 flex-wrap">
              {images.map((img, i) => (
                <div
                  key={i}
                  style={{
                    width: 72,
                    height: 72,
                    borderRadius: 12,
                    overflow: 'hidden',
                    position: 'relative',
                  }}
                >
                  <img src={img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <button
                    onClick={() => setImages(prev => prev.filter((_, idx) => idx !== i))}
                    style={{
                      position: 'absolute',
                      top: 2,
                      right: 2,
                      width: 20,
                      height: 20,
                      borderRadius: '50%',
                      background: 'rgba(0,0,0,0.6)',
                      border: 'none',
                      color: 'white',
                      fontSize: 12,
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    ×
                  </button>
                </div>
              ))}
              {images.length < 5 && (
                <button
                  onClick={() => fileRef.current?.click()}
                  style={{
                    width: 72,
                    height: 72,
                    borderRadius: 12,
                    border: '2px dashed #ddd',
                    background: '#F5F5F7',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 4,
                    cursor: 'pointer',
                  }}
                >
                  <Camera size={20} color="#aaa" />
                  <span style={{ fontSize: 10, color: '#aaa', fontWeight: 600 }}>Ajouter</span>
                </button>
              )}
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              multiple
              style={{ display: 'none' }}
              onChange={handleImageChange}
            />
          </div>

          {/* Submit */}
          <button
            onClick={handleSubmit}
            disabled={loading}
            style={{
              width: '100%',
              padding: '16px',
              borderRadius: 16,
              background: loading ? '#ddd' : '#FFD700',
              border: 'none',
              fontSize: 16,
              fontWeight: 800,
              color: '#111',
              cursor: loading ? 'not-allowed' : 'pointer',
              boxShadow: loading ? 'none' : '0 6px 20px rgba(255,215,0,0.4)',
              transition: 'all 0.2s',
            }}
          >
            {loading ? '⏳ Publication...' : '🚀 Publier maintenant'}
          </button>
        </div>
      </div>
    </div>
  );
}
