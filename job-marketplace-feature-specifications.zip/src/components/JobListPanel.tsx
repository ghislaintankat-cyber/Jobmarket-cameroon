import { useState } from 'react';
import { X, SlidersHorizontal, ChevronDown } from 'lucide-react';
import type { Job, FilterOptions } from '../types';
import type { CategoryKey } from '../types';
import JobCard from './JobCard';

interface JobListPanelProps {
  jobs: Job[];
  savedJobIds: Set<string>;
  onClose: () => void;
  onSave: (id: string) => void;
  onReport: (id: string) => void;
  onSelectJob: (job: Job) => void;
  filters: FilterOptions;
  onFiltersChange: (f: FilterOptions) => void;
}

export default function JobListPanel({
  jobs,
  savedJobIds,
  onClose,
  onSave,
  onReport,
  onSelectJob,
  filters,
  onFiltersChange,
}: JobListPanelProps) {
  const [showFilters, setShowFilters] = useState(false);

  return (
    <div
      className="fixed inset-0 flex flex-col"
      style={{
        background: '#F5F5F7',
        zIndex: 200,
        paddingTop: 60,
        paddingBottom: 80,
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-4 py-3"
        style={{ background: 'white', boxShadow: '0 2px 10px rgba(0,0,0,0.06)' }}
      >
        <div>
          <div style={{ fontWeight: 800, fontSize: 18, color: '#111' }}>Jobs proches</div>
          <div style={{ fontSize: 12, color: '#888', fontWeight: 500 }}>{jobs.length} disponibles</div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowFilters(!showFilters)}
            style={{
              background: showFilters ? '#FFD700' : '#F5F5F7',
              border: 'none',
              borderRadius: 12,
              width: 40,
              height: 40,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
            }}
          >
            <SlidersHorizontal size={18} color={showFilters ? '#111' : '#666'} />
          </button>
          <button
            onClick={onClose}
            style={{
              background: '#F5F5F7',
              border: 'none',
              borderRadius: 12,
              width: 40,
              height: 40,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
            }}
          >
            <X size={18} color="#666" />
          </button>
        </div>
      </div>

      {/* Filters panel */}
      {showFilters && (
        <div
          className="px-4 py-3 flex flex-col gap-3"
          style={{ background: 'white', borderBottom: '1px solid #eee' }}
        >
          {/* Sort */}
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#888', marginBottom: 8 }}>TRIER PAR</div>
            <div className="flex gap-2 flex-wrap">
              {[
                { key: 'distance', label: '📍 Distance' },
                { key: 'rating', label: '⭐ Note' },
                { key: 'recent', label: '🕒 Récent' },
                { key: 'price', label: '💰 Prix' },
              ].map(s => (
                <button
                  key={s.key}
                  onClick={() => onFiltersChange({ ...filters, sortBy: s.key as FilterOptions['sortBy'] })}
                  style={{
                    background: filters.sortBy === s.key ? '#FFD700' : '#F5F5F7',
                    border: 'none',
                    borderRadius: 20,
                    padding: '7px 12px',
                    fontSize: 12,
                    fontWeight: 700,
                    color: '#111',
                    cursor: 'pointer',
                  }}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Verified only */}
          <div className="flex items-center justify-between">
            <span style={{ fontSize: 13, fontWeight: 700, color: '#111' }}>✓ Vérifiés uniquement</span>
            <button
              onClick={() => onFiltersChange({ ...filters, verifiedOnly: !filters.verifiedOnly })}
              style={{
                width: 48,
                height: 28,
                borderRadius: 14,
                background: filters.verifiedOnly ? '#007AFF' : '#ddd',
                border: 'none',
                position: 'relative',
                cursor: 'pointer',
                transition: 'all 0.2s',
              }}
            >
              <div
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: '50%',
                  background: 'white',
                  position: 'absolute',
                  top: 3,
                  left: filters.verifiedOnly ? 23 : 3,
                  transition: 'all 0.2s',
                  boxShadow: '0 1px 4px rgba(0,0,0,0.2)',
                }}
              />
            </button>
          </div>

          {/* Max distance */}
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#888', marginBottom: 8 }}>
              DISTANCE MAX: {filters.maxDistance ? `${filters.maxDistance} km` : 'Toutes'}
            </div>
            <div className="flex gap-2">
              {[null, 2, 5, 10, 20].map(d => (
                <button
                  key={String(d)}
                  onClick={() => onFiltersChange({ ...filters, maxDistance: d })}
                  style={{
                    background: filters.maxDistance === d ? '#111' : '#F5F5F7',
                    border: 'none',
                    borderRadius: 20,
                    padding: '7px 12px',
                    fontSize: 12,
                    fontWeight: 700,
                    color: filters.maxDistance === d ? 'white' : '#111',
                    cursor: 'pointer',
                  }}
                >
                  {d ? `${d}km` : 'Tous'}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Jobs list */}
      <div className="flex-1 overflow-y-auto px-4 pt-3">
        {jobs.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48">
            <div style={{ fontSize: 40, marginBottom: 12 }}>🔍</div>
            <div style={{ fontWeight: 700, fontSize: 16, color: '#333' }}>Aucun job trouvé</div>
            <div style={{ fontSize: 13, color: '#888', marginTop: 4 }}>Modifiez vos filtres</div>
          </div>
        ) : (
          jobs.map(job => (
            <JobCard
              key={job.id}
              job={job}
              isSaved={savedJobIds.has(job.id)}
              onSave={() => onSave(job.id)}
              onReport={() => onReport(job.id)}
              onContact={() => window.open(`tel:${job.phone}`)}
              onSelect={() => onSelectJob(job)}
            />
          ))
        )}
      </div>
    </div>
  );
}
