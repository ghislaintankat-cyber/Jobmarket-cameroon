import { useState, useMemo } from 'react';
import { Search, X } from 'lucide-react';
import type { Job } from '../types';
import JobCard from './JobCard';

interface SearchPanelProps {
  jobs: Job[];
  savedJobIds: Set<string>;
  onSave: (id: string) => void;
  onReport: (id: string) => void;
  onSelectJob: (job: Job) => void;
}

export default function SearchPanel({
  jobs,
  savedJobIds,
  onSave,
  onReport,
  onSelectJob,
}: SearchPanelProps) {
  const [query, setQuery] = useState('');

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return jobs.filter(
      j =>
        j.title.toLowerCase().includes(q) ||
        j.desc.toLowerCase().includes(q) ||
        j.landmark.toLowerCase().includes(q) ||
        j.userName.toLowerCase().includes(q)
    );
  }, [query, jobs]);

  const recent = ['Électricien', 'Maçon', 'Ménage', 'Plombier', 'Yaoundé'];

  return (
    <div
      className="fixed inset-0 flex flex-col"
      style={{ background: '#F5F5F7', zIndex: 200, paddingTop: 60, paddingBottom: 80 }}
    >
      {/* Search input */}
      <div
        className="px-4 py-3"
        style={{ background: 'white', boxShadow: '0 2px 10px rgba(0,0,0,0.06)' }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            background: '#F5F5F7',
            borderRadius: 16,
            padding: '12px 16px',
          }}
        >
          <Search size={18} color="#888" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Rechercher un job, une compétence..."
            autoFocus
            style={{
              flex: 1,
              border: 'none',
              background: 'none',
              fontSize: 15,
              fontWeight: 500,
              fontFamily: 'inherit',
              outline: 'none',
              color: '#111',
            }}
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              style={{ border: 'none', background: 'none', cursor: 'pointer' }}
            >
              <X size={16} color="#888" />
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pt-4">
        {!query ? (
          <div>
            <div style={{ fontWeight: 700, fontSize: 13, color: '#888', marginBottom: 10 }}>
              RECHERCHES RÉCENTES
            </div>
            <div className="flex gap-2 flex-wrap mb-6">
              {recent.map(r => (
                <button
                  key={r}
                  onClick={() => setQuery(r)}
                  style={{
                    background: 'white',
                    border: 'none',
                    borderRadius: 20,
                    padding: '8px 14px',
                    fontSize: 13,
                    fontWeight: 600,
                    color: '#333',
                    cursor: 'pointer',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
                  }}
                >
                  🔍 {r}
                </button>
              ))}
            </div>

            <div style={{ fontWeight: 700, fontSize: 13, color: '#888', marginBottom: 10 }}>
              JOBS POPULAIRES
            </div>
            {jobs.slice(0, 3).map(job => (
              <JobCard
                key={job.id}
                job={job}
                isSaved={savedJobIds.has(job.id)}
                onSave={() => onSave(job.id)}
                onReport={() => onReport(job.id)}
                onContact={() => window.open(`tel:${job.phone}`)}
                onSelect={() => onSelectJob(job)}
                compact
              />
            ))}
          </div>
        ) : results.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48">
            <div style={{ fontSize: 40, marginBottom: 12 }}>🔍</div>
            <div style={{ fontWeight: 700, fontSize: 16, color: '#333' }}>Aucun résultat</div>
            <div style={{ fontSize: 13, color: '#888', marginTop: 4 }}>
              Essayez d'autres mots-clés
            </div>
          </div>
        ) : (
          <div>
            <div style={{ fontWeight: 700, fontSize: 13, color: '#888', marginBottom: 10 }}>
              {results.length} RÉSULTAT{results.length > 1 ? 'S' : ''}
            </div>
            {results.map(job => (
              <JobCard
                key={job.id}
                job={job}
                isSaved={savedJobIds.has(job.id)}
                onSave={() => onSave(job.id)}
                onReport={() => onReport(job.id)}
                onContact={() => window.open(`tel:${job.phone}`)}
                onSelect={() => onSelectJob(job)}
                compact
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
