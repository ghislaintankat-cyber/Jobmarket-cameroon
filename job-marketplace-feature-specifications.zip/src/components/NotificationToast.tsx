import { useEffect, useState } from 'react';
import type { Notification } from '../types';

interface NotificationToastProps {
  notification: Notification | null;
  onDismiss: () => void;
}

export default function NotificationToast({ notification, onDismiss }: NotificationToastProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (notification) {
      setVisible(true);
      const timer = setTimeout(() => {
        setVisible(false);
        setTimeout(onDismiss, 300);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [notification, onDismiss]);

  if (!notification) return null;

  return (
    <div
      style={{
        position: 'fixed',
        top: 72,
        left: 12,
        right: 12,
        zIndex: 500,
        background: 'rgba(17,17,17,0.92)',
        backdropFilter: 'blur(12px)',
        borderRadius: 18,
        padding: '14px 16px',
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
        transform: visible ? 'translateY(0)' : 'translateY(-20px)',
        opacity: visible ? 1 : 0,
        transition: 'all 0.3s cubic-bezier(0.32, 0.72, 0, 1)',
        cursor: 'pointer',
      }}
      onClick={() => { setVisible(false); setTimeout(onDismiss, 300); }}
    >
      <div style={{ fontSize: 22, flexShrink: 0 }}>
        {notification.type === 'new_job' ? '📍' :
         notification.type === 'message' ? '💬' :
         notification.type === 'rating' ? '⭐' : '🔔'}
      </div>
      <div className="flex-1 min-w-0">
        <div style={{ fontWeight: 800, fontSize: 13, color: 'white', marginBottom: 2 }}>
          {notification.title}
        </div>
        <div style={{ fontSize: 12, color: '#aaa', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {notification.body}
        </div>
      </div>
      <div
        style={{
          background: '#FFD700',
          borderRadius: 10,
          padding: '4px 10px',
          fontSize: 11,
          fontWeight: 800,
          color: '#111',
        }}
      >
        Voir
      </div>
    </div>
  );
}
