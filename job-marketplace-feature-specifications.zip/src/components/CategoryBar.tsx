import { CATEGORIES } from '../data/categories';
import type { CategoryKey } from '../types';

interface CategoryBarProps {
  active: CategoryKey;
  onChange: (key: CategoryKey) => void;
}

export default function CategoryBar({ active, onChange }: CategoryBarProps) {
  return (
    <div
      className="fixed left-0 right-0 flex gap-2 overflow-x-auto px-3"
      style={{
        top: 68,
        zIndex: 50,
        scrollbarWidth: 'none',
        WebkitOverflowScrolling: 'touch',
        paddingBottom: 4,
      }}
    >
      {CATEGORIES.map(cat => {
        const isActive = active === cat.key;
        return (
          <button
            key={cat.key}
            onClick={() => onChange(cat.key)}
            style={{
              background: isActive ? cat.bg : 'rgba(255,255,255,0.95)',
              color: isActive ? cat.color : '#333',
              border: 'none',
              borderRadius: 20,
              padding: '9px 14px',
              fontWeight: 800,
              fontSize: 13,
              whiteSpace: 'nowrap',
              cursor: 'pointer',
              boxShadow: isActive
                ? `0 4px 16px ${cat.bg}55`
                : '0 2px 10px rgba(0,0,0,0.12)',
              flexShrink: 0,
              transition: 'all 0.2s',
              display: 'flex',
              alignItems: 'center',
              gap: 5,
            }}
          >
            {cat.icon} {cat.label}
          </button>
        );
      })}
    </div>
  );
}
