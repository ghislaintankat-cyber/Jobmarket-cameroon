import { useState, useCallback } from 'react';
import type { Job, FilterOptions } from '../types';
import { MOCK_JOBS } from '../data/mockData';
import type { Coords } from './useGeolocation';

function haversineDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export function useJobs() {
  const [jobs, setJobs] = useState<Job[]>(MOCK_JOBS);
  const [savedJobIds, setSavedJobIds] = useState<Set<string>>(new Set());
  const [_loading] = useState(false);

  const updateDistances = useCallback((userCoords: Coords) => {
    setJobs(prev =>
      prev.map(job => ({
        ...job,
        dist: parseFloat(
          haversineDistance(userCoords.lat, userCoords.lng, job.lat, job.lng).toFixed(1)
        ),
      }))
    );
  }, []);

  const addJob = useCallback((jobData: Omit<Job, 'id' | 'timestamp' | 'dist'>) => {
    const newJob: Job = {
      ...jobData,
      id: 'job_' + Date.now(),
      timestamp: Date.now(),
      dist: 0,
    };
    setJobs(prev => [newJob, ...prev]);
  }, []);

  const toggleSave = useCallback((jobId: string) => {
    setSavedJobIds(prev => {
      const next = new Set(prev);
      if (next.has(jobId)) next.delete(jobId);
      else next.add(jobId);
      return next;
    });
  }, []);

  const filterJobs = useCallback(
    (all: Job[], filters: FilterOptions): Job[] => {
      let result = [...all];

      if (filters.category !== 'all') {
        result = result.filter(j => j.category === filters.category);
      }
      if (filters.minPrice !== null) {
        result = result.filter(j => parseInt(j.price) >= (filters.minPrice ?? 0));
      }
      if (filters.maxPrice !== null) {
        result = result.filter(j => parseInt(j.price) <= (filters.maxPrice ?? Infinity));
      }
      if (filters.verifiedOnly) {
        result = result.filter(j => j.verified);
      }
      if (filters.maxDistance !== null) {
        result = result.filter(j => (j.dist ?? 999) <= (filters.maxDistance ?? 999));
      }

      switch (filters.sortBy) {
        case 'distance':
          result.sort((a, b) => (a.dist ?? 999) - (b.dist ?? 999));
          break;
        case 'rating':
          result.sort((a, b) => b.ratingAvg - a.ratingAvg);
          break;
        case 'recent':
          result.sort((a, b) => b.timestamp - a.timestamp);
          break;
        case 'price':
          result.sort((a, b) => parseInt(a.price) - parseInt(b.price));
          break;
      }

      return result;
    },
    []
  );

  const reportJob = useCallback((jobId: string, reason: string) => {
    console.log('Report job:', jobId, reason);
    // In real app: save to Firebase
  }, []);

  return {
    jobs,
    savedJobIds,
    updateDistances,
    addJob,
    toggleSave,
    filterJobs,
    reportJob,
  };
}
