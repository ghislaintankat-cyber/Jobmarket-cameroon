import { useState, useCallback } from 'react';

export interface Coords {
  lat: number;
  lng: number;
  accuracy?: number;
}

export function useGeolocation() {
  const [coords, setCoords] = useState<Coords | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const locate = useCallback((onSuccess?: (c: Coords) => void) => {
    if (!navigator.geolocation) {
      setError('Géolocalisation non supportée');
      return;
    }
    setLoading(true);
    setError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const c: Coords = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        };
        setCoords(c);
        setLoading(false);
        onSuccess?.(c);
      },
      (err) => {
        setError(err.message);
        setLoading(false);
        // Default to Yaoundé center if geolocation fails
        const defaultCoords = { lat: 3.848, lng: 11.502 };
        setCoords(defaultCoords);
        onSuccess?.(defaultCoords);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  }, []);

  return { coords, loading, error, locate };
}
