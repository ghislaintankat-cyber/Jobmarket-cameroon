import { useState, useRef, useEffect, useCallback } from 'react';
import L from 'leaflet';
import type { Job, TabType, CategoryKey, FilterOptions, Notification } from './types';
import { useGeolocation } from './hooks/useGeolocation';
import { useJobs } from './hooks/useJobs';
import { MOCK_NOTIFICATIONS } from './data/mockData';

import MapView from './components/MapView';
import TopBar from './components/TopBar';
import CategoryBar from './components/CategoryBar';
import MapControls from './components/MapControls';
import BottomNav from './components/BottomNav';
import JobListPanel from './components/JobListPanel';
import PostJobDrawer from './components/PostJobDrawer';
import AccountPanel from './components/AccountPanel';
import SearchPanel from './components/SearchPanel';
import NotificationToast from './components/NotificationToast';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('map');
  const [activeCategory, setActiveCategory] = useState<CategoryKey>('all');
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [showPostForm, setShowPostForm] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>(MOCK_NOTIFICATIONS);
  const [toastNotif, setToastNotif] = useState<Notification | null>(null);
  const [filters, setFilters] = useState<FilterOptions>({
    category: 'all',
    minPrice: null,
    maxPrice: null,
    verifiedOnly: false,
    maxDistance: null,
    sortBy: 'distance',
  });

  const mapRef = useRef<L.Map | null>(null);

  const { coords: userCoords, loading: locating, locate } = useGeolocation();
  const {
    jobs,
    savedJobIds,
    updateDistances,
    addJob,
    toggleSave,
    filterJobs,
    reportJob,
  } = useJobs();

  // Locate on mount
  useEffect(() => {
    locate((c) => updateDistances(c));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Simulate a new notification after 5s
  useEffect(() => {
    const timer = setTimeout(() => {
      const newNotif: Notification = {
        id: 'n_live',
        title: '📍 Nouveau job à 1.5 km !',
        body: 'Électricien Expert — 15 000 XAF — Bastos',
        timestamp: Date.now(),
        read: false,
        type: 'new_job',
      };
      setToastNotif(newNotif);
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  const filteredJobs = filterJobs(jobs, {
    ...filters,
    category: activeCategory,
  });

  const nearestJobDist = filteredJobs.length > 0
    ? Math.min(...filteredJobs.filter(j => j.dist !== undefined).map(j => j.dist!))
    : null;

  const unreadNotifCount = notifications.filter(n => !n.read).length;

  const handleTabChange = (tab: TabType) => {
    if (tab === 'post') {
      setShowPostForm(true);
      return;
    }
    setActiveTab(tab);
    setShowPostForm(false);
  };

  const handleJobSelect = useCallback((job: Job) => {
    setSelectedJob(job);
    setActiveTab('map');
    setShowPostForm(false);
  }, []);

  const handleLocate = useCallback(() => {
    locate((c) => {
      updateDistances(c);
    });
  }, [locate, updateDistances]);

  const handleToggleLayer = useCallback(() => {
    const map = mapRef.current;
    if (!map) return;
    // Toggle tile layers
    const layers: L.Layer[] = [];
    map.eachLayer(layer => {
      if (layer instanceof L.TileLayer) layers.push(layer);
    });
    layers.forEach(l => map.removeLayer(l));

    // Check if current is satellite by checking if we have google tiles
    const hasSatellite = layers.some(l => (l as L.TileLayer).options && (l as L.TileLayer).options.subdomains);
    if (!hasSatellite) {
      L.tileLayer('https://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}', {
        subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
        maxZoom: 20,
      }).addTo(map);
    } else {
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
      }).addTo(map);
    }
  }, []);

  const handleReport = useCallback((jobId: string) => {
    const reasons = ['Escroquerie', 'Faux profil', 'Prix abusif', 'Contenu inapproprié'];
    const reason = window.prompt(`Signaler ce job:\n${reasons.map((r, i) => `${i + 1}. ${r}`).join('\n')}\n\nNuméro:`) || '';
    if (reason) {
      reportJob(jobId, reasons[parseInt(reason) - 1] || reason);
      alert('✅ Signalement envoyé. Notre équipe va vérifier.');
    }
  }, [reportJob]);

  const savedJobs = jobs.filter(j => savedJobIds.has(j.id));

  const showMap = activeTab === 'map' && !showPostForm;
  const showList = activeTab === 'list' && !showPostForm;
  const showSearch = activeTab === 'search' && !showPostForm;
  const showAccount = activeTab === 'account' && !showPostForm;

  return (
    <div style={{ position: 'fixed', inset: 0, overflow: 'hidden' }}>
      {/* Map — always rendered behind everything */}
      <MapView
        jobs={filteredJobs}
        userCoords={userCoords}
        selectedJob={selectedJob}
        onJobSelect={handleJobSelect}
        onMapClick={() => setSelectedJob(null)}
        mapRef={mapRef}
      />

      {/* Top bar — always visible */}
      <TopBar
        notifCount={unreadNotifCount}
        onNotifClick={() => { setActiveTab('account'); setShowPostForm(false); }}
        onPublishClick={() => setShowPostForm(true)}
      />

      {/* Category bar — only on map view */}
      {showMap && (
        <CategoryBar
          active={activeCategory}
          onChange={cat => {
            setActiveCategory(cat);
            setFilters(prev => ({ ...prev, category: cat }));
          }}
        />
      )}

      {/* Map controls — only on map view */}
      {showMap && (
        <MapControls
          mapRef={mapRef}
          onLocate={handleLocate}
          onToggleLayer={handleToggleLayer}
          locating={locating}
          nearestJobDist={nearestJobDist}
        />
      )}

      {/* List panel */}
      {showList && (
        <JobListPanel
          jobs={filteredJobs}
          savedJobIds={savedJobIds}
          onClose={() => setActiveTab('map')}
          onSave={toggleSave}
          onReport={handleReport}
          onSelectJob={handleJobSelect}
          filters={filters}
          onFiltersChange={setFilters}
        />
      )}

      {/* Search panel */}
      {showSearch && (
        <SearchPanel
          jobs={jobs}
          savedJobIds={savedJobIds}
          onSave={toggleSave}
          onReport={handleReport}
          onSelectJob={handleJobSelect}
        />
      )}

      {/* Account panel */}
      {showAccount && (
        <AccountPanel
          savedJobs={savedJobs}
          savedJobIds={savedJobIds}
          onSave={toggleSave}
          onSelectJob={handleJobSelect}
          notifications={notifications}
          onMarkAllRead={() =>
            setNotifications(prev => prev.map(n => ({ ...n, read: true })))
          }
        />
      )}

      {/* Post job drawer */}
      {showPostForm && (
        <PostJobDrawer
          onClose={() => setShowPostForm(false)}
          onSubmit={jobData => {
            addJob(jobData);
            setActiveTab('map');
            setShowPostForm(false);
          }}
          userCoords={userCoords}
          userId="local_user"
        />
      )}

      {/* Notification toast */}
      <NotificationToast
        notification={toastNotif}
        onDismiss={() => setToastNotif(null)}
      />

      {/* Bottom nav */}
      <BottomNav active={showPostForm ? 'post' : activeTab} onChange={handleTabChange} />
    </div>
  );
}
